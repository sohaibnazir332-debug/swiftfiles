import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/swipe_service.dart';
import 'browser_provider.dart';
import 'settings_provider.dart';

/// Swipe Saaf ki yaaddasht: jo files aap ne "rakho" kahi wo dobara nahi poochi
/// jaati, aur ab tak kitni jagah khali hui.
class SwipeStore {
  SwipeStore(this._prefs);

  final SharedPreferences _prefs;

  static const _kKept = 'swipe_kept';
  static const _kFreed = 'swipe_freed';
  static const _kWa = 'swipe_whatsapp';
  static const _maxKept = 4000;

  Set<String> get kept =>
      (_prefs.getStringList(_kKept) ?? const <String>[]).toSet();

  void addKept(Iterable<String> paths) {
    final list = [...(_prefs.getStringList(_kKept) ?? const <String>[])];
    final have = list.toSet();
    for (final x in paths) {
      if (have.add(x)) list.add(x);
    }
    final trimmed =
        list.length > _maxKept ? list.sublist(list.length - _maxKept) : list;
    _prefs.setStringList(_kKept, trimmed);
  }

  void removeKept(Iterable<String> paths) {
    final drop = paths.toSet();
    final list = [...(_prefs.getStringList(_kKept) ?? const <String>[])]
      ..removeWhere(drop.contains);
    _prefs.setStringList(_kKept, list);
  }

  bool get includeWhatsApp => _prefs.getBool(_kWa) ?? false;

  void setIncludeWhatsApp(bool v) => _prefs.setBool(_kWa, v);

  int get totalFreed => _prefs.getInt(_kFreed) ?? 0;

  void addFreed(int bytes) {
    if (bytes <= 0) return;
    _prefs.setInt(_kFreed, totalFreed + bytes);
  }
}

final swipeStoreProvider = Provider<SwipeStore>(
  (ref) => SwipeStore(ref.read(sharedPrefsProvider)),
);

final swipeServiceProvider = Provider<SwipeService>((ref) {
  final s = SwipeService(ref.read(fileServiceProvider));
  ref.onDispose(s.cancel);
  return s;
});
