import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;

import 'file_service.dart';

/// Swipe Saaf ke cards ki qism.
enum CardKind { dup, apk, sent, big, screenshot, download, whatsapp, archive }

class SwipeFile {
  const SwipeFile(this.path, this.size, this.modified);
  final String path;
  final int size;
  final DateTime modified;
}

/// Ek card = ek file (ya duplicate copies ka ek group).
class SwipeCard {
  SwipeCard(this.kind, this.reclaim, this.files);

  final CardKind kind;

  /// Delete karne par kitni jagah bachegi
  final int reclaim;

  /// Duplicate card mein: pehli file wahi hai jo rakhne ke liye behtar hai.
  final List<SwipeFile> files;

  bool get isDup => kind == CardKind.dup;

  /// Delete hone wali files (dup mein `keepIdx` wali chhod kar baaki).
  List<SwipeFile> toDelete(int keepIdx) {
    if (!isDup) return files;
    return [
      for (var i = 0; i < files.length; i++)
        if (i != keepIdx) files[i],
    ];
  }

  static int _score(String path) {
    final l = path.toLowerCase();
    if (l.contains('whatsapp') || l.contains('telegram')) return 3;
    if (l.contains('download') || l.contains('screenshot')) return 2;
    return 0;
  }

  /// Duplicate group: jo copy rakhni chahiye wo index 0 par.
  static SwipeCard dup(int size, List<SwipeFile> raw) {
    final files = [...raw]..sort((a, b) {
        final s = _score(a.path).compareTo(_score(b.path));
        return s != 0 ? s : a.modified.compareTo(b.modified);
      });
    return SwipeCard(CardKind.dup, size * (files.length - 1), files);
  }
}

class JunkItem {
  const JunkItem(this.path, this.size, this.isDir);
  final String path;
  final int size;
  final bool isDir;
}

class SwipeScanResult {
  const SwipeScanResult({
    required this.cards,
    required this.junk,
    required this.scanned,
  });

  final List<SwipeCard> cards; // sabse zyada jagah wale pehle
  final List<JunkItem> junk;
  final int scanned;

  int get junkBytes => junk.fold(0, (s, j) => s + j.size);
  int get reclaimable => cards.fold(0, (s, c) => s + c.reclaim);
}

class SwipeProgress {
  const SwipeProgress(this.phase, this.done);
  final String phase;
  final int done;
}

/// "Ek Swipe Saaf" ka scanner. Poora kaam alag isolate mein hota hai.
/// System / app-data folders kabhi scan nahi hote, aur Favorite (⭐) ya pehle
/// "rakho" kiye hue items kabhi card mein nahi aate.
class SwipeService {
  SwipeService(this._fs);

  final FileService _fs;
  Isolate? _isolate;
  ReceivePort? _port;
  Completer<SwipeScanResult>? _completer;

  void cancel() {
    _isolate?.kill(priority: Isolate.immediate);
    _isolate = null;
    _port?.close();
    _port = null;
    final c = _completer;
    if (c != null && !c.isCompleted) c.completeError(FileOpException('cancelled'));
  }

  Future<SwipeScanResult> scan({
    required Set<String> favorites,
    required Set<String> kept,
    bool includeWhatsApp = false,
    void Function(SwipeProgress)? onProgress,
  }) async {
    cancel();
    final port = ReceivePort();
    final done = Completer<SwipeScanResult>();
    _port = port;
    _completer = done;

    port.listen((dynamic m) {
      if (done.isCompleted || m is! List || m.isEmpty) return;
      switch (m[0]) {
        case 'progress':
          onProgress?.call(SwipeProgress(m[1] as String, m[2] as int));
        case 'done':
          final cards = <SwipeCard>[];
          for (final c in (m[1] as List)) {
            final kind = CardKind.values[c[0] as int];
            final reclaim = c[1] as int;
            final files = <SwipeFile>[
              for (final f in (c[2] as List))
                SwipeFile(
                  f[0] as String,
                  f[1] as int,
                  DateTime.fromMillisecondsSinceEpoch(f[2] as int),
                ),
            ];
            if (files.isEmpty) continue;
            cards.add(
              kind == CardKind.dup
                  ? SwipeCard.dup(files.first.size, files)
                  : SwipeCard(kind, reclaim, files),
            );
          }
          final junk = <JunkItem>[
            for (final j in (m[2] as List))
              JunkItem(j[0] as String, j[1] as int, (j[2] as int) == 1),
          ];
          done.complete(
            SwipeScanResult(cards: cards, junk: junk, scanned: m[3] as int),
          );
        case 'error':
          done.completeError(FileOpException(m[1] as String));
        default:
          // Isolate crash
          done.completeError(FileOpException('Scan poora nahi ho saka'));
      }
    });

    try {
      _isolate = await Isolate.spawn(
        _swipeWorker,
        <Object>[
          port.sendPort,
          _fs.root.path,
          _fs.trashDir.path,
          favorites.toList(),
          kept.toList(),
          Platform.isWindows,
          DateTime.now().millisecondsSinceEpoch,
          includeWhatsApp,
        ],
        onError: port.sendPort,
      );
      return await done.future;
    } finally {
      port.close();
      _isolate?.kill(priority: Isolate.immediate);
      _isolate = null;
      _port = null;
    }
  }

  /// Faltu files (temp, cache, khali folders) seedha hamesha ke liye delete.
  /// Wapas deti hai kitni jagah khali hui.
  Future<int> deleteJunk(List<JunkItem> items) async {
    var freed = 0;
    for (final j in items) {
      try {
        if (j.isDir) {
          final d = Directory(j.path);
          if (await d.exists()) await d.delete(recursive: true);
        } else {
          final f = File(j.path);
          if (await f.exists()) await f.delete();
        }
        freed += j.size;
      } catch (_) {
        // delete na ho sake to chhod do
      }
    }
    return freed;
  }
}

// -----------------------------------------------------------------------------
// Background isolate
// -----------------------------------------------------------------------------

const _imgExt = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.heic'};
const _vidExt = {'.mp4', '.mkv', '.3gp', '.mov', '.avi', '.webm', '.m4v'};
const _arcExt = {'.zip', '.rar', '.7z', '.tar', '.gz'};
const _junkExt = {'.tmp', '.temp', '.crdownload', '.part', '.partial', '.download'};
const _mb = 1024 * 1024;

class _E {
  _E(this.path, this.size, this.ms);
  final String path;
  final int size;
  final int ms;
}

class _Sink implements Sink<Digest> {
  Digest? value;
  @override
  void add(Digest data) => value = data;
  @override
  void close() {}
}

String? _sha(String path, {int? limit}) {
  RandomAccessFile? raf;
  try {
    raf = File(path).openSync();
    final sink = _Sink();
    final conv = sha1.startChunkedConversion(sink);
    var remaining = limit ?? raf.lengthSync();
    while (remaining > 0) {
      final chunk = raf.readSync(min(1 << 20, remaining));
      if (chunk.isEmpty) break;
      conv.add(chunk);
      remaining -= chunk.length;
    }
    conv.close();
    return sink.value?.toString();
  } catch (_) {
    return null;
  } finally {
    try {
      raf?.closeSync();
    } catch (_) {}
  }
}

int _dirSize(String path) {
  var total = 0;
  try {
    for (final e in Directory(path).listSync(recursive: true, followLinks: false)) {
      if (e is File) {
        try {
          total += e.lengthSync();
        } catch (_) {}
      }
    }
  } catch (_) {}
  return total;
}

void _swipeWorker(List<Object> a) {
  final send = a[0] as SendPort;
  final root = a[1] as String;
  final trash = a[2] as String;
  final favs = (a[3] as List).cast<String>();
  final favSet = favs.toSet();
  final kept = (a[4] as List).cast<String>().toSet();
  final windows = a[5] as bool;
  final nowMs = a[6] as int;
  final includeWa = a[7] as bool;

  try {
    bool isFav(String path) {
      if (favs.isEmpty) return false;
      if (favSet.contains(path)) return true;
      for (final f in favs) {
        if (p.isWithin(f, path)) return true;
      }
      return false;
    }

    final androidDir = p.join(root, 'Android');
    final files = <_E>[];
    final junk = <List<Object>>[];
    final stack = <Directory>[Directory(root)];
    var seen = 0;

    while (stack.isNotEmpty) {
      final d = stack.removeLast();
      List<FileSystemEntity> kids;
      try {
        kids = d.listSync(followLinks: false);
      } catch (_) {
        continue;
      }

      // Khali folder (top-level folders aur Android ke andar wale chhod kar)
      if (kids.isEmpty &&
          !p.equals(d.path, root) &&
          !p.equals(p.dirname(d.path), root) &&
          !p.isWithin(androidDir, d.path) &&
          !isFav(d.path)) {
        junk.add(<Object>[d.path, 0, 1]);
        continue;
      }

      for (final e in kids) {
        final name = p.basename(e.path);
        final lower = name.toLowerCase();
        if (p.equals(e.path, trash)) continue;

        if (e is Directory) {
          if (lower == '.thumbnails') {
            junk.add(<Object>[e.path, _dirSize(e.path), 1]);
            continue;
          }
          if (name.startsWith('.')) continue;
          if (lower == 'node_modules') continue;
          if (windows) {
            if (lower == 'appdata' ||
                lower == r'$recycle.bin' ||
                lower == 'system volume information') {
              continue;
            }
          } else if (p.equals(d.path, root) && lower == 'android') {
            if (!includeWa) continue;
            // Sirf WhatsApp / Telegram ki media dekhte hain. Baaqi apps ka data nahi.
            final media = Directory(p.join(e.path, 'media'));
            try {
              if (media.existsSync()) {
                for (final k in media.listSync(followLinks: false)) {
                  final kn = p.basename(k.path).toLowerCase();
                  if (k is Directory &&
                      (kn.contains('whatsapp') || kn.contains('telegram'))) {
                    stack.add(k);
                  }
                }
              }
            } catch (_) {}
            continue;
          }
          stack.add(e);
        } else if (e is File) {
          final ext = p.extension(lower);
          if (_junkExt.contains(ext) || lower == 'thumbs.db' || lower == '.ds_store') {
            try {
              final sz = e.lengthSync();
              if (!isFav(e.path)) junk.add(<Object>[e.path, sz, 0]);
            } catch (_) {}
            continue;
          }
          if (name.startsWith('.')) continue;
          if (windows && lower.startsWith('ntuser')) continue;
          if (!includeWa && e.path.toLowerCase().contains('whatsapp')) continue;
          seen++;
          if (seen % 400 == 0) {
            send.send(<Object>['progress', 'Files gin rahe hain', seen]);
          }
          if (kept.contains(e.path) || isFav(e.path)) continue;
          try {
            final st = e.statSync();
            if (st.size <= 0) continue;
            files.add(_E(e.path, st.size, st.modified.millisecondsSinceEpoch));
          } catch (_) {}
        }
      }
    }

    // ---- duplicates (size -> shuru ka hash -> poora hash) ----
    final used = <String>{};
    final cards = <List<Object>>[];
    final bySize = <int, List<_E>>{};
    for (final e in files) {
      if (e.size >= 100 * 1024) (bySize[e.size] ??= []).add(e);
    }
    final candidates = bySize.values.where((l) => l.length > 1).toList();
    var hashed = 0;
    for (final sameSize in candidates) {
      final byPartial = <String, List<_E>>{};
      for (final e in sameSize) {
        final h = _sha(e.path, limit: 64 * 1024);
        hashed++;
        if (hashed % 10 == 0) {
          send.send(<Object>['progress', 'Duplicates dhoondh rahe hain', hashed]);
        }
        if (h != null) (byPartial[h] ??= []).add(e);
      }
      for (final part in byPartial.values) {
        if (part.length < 2) continue;
        final byFull = <String, List<_E>>{};
        for (final e in part) {
          final h = _sha(e.path);
          if (h != null) (byFull[h] ??= []).add(e);
        }
        for (final same in byFull.values) {
          if (same.length < 2) continue;
          for (final e in same) {
            used.add(e.path);
          }
          cards.add(<Object>[
            CardKind.dup.index,
            same.first.size * (same.length - 1),
            [
              for (final e in same) <Object>[e.path, e.size, e.ms],
            ],
          ]);
        }
      }
    }

    // ---- baaqi cards ----
    const dayMs = 86400000;
    for (final e in files) {
      if (used.contains(e.path)) continue;
      final lp = e.path.toLowerCase().replaceAll('\\', '/');
      final ext = p.extension(lp);
      final ageDays = (nowMs - e.ms) ~/ dayMs;
      final isMedia = _imgExt.contains(ext) || _vidExt.contains(ext);
      final inDownloads = lp.contains('/download/') || lp.contains('/downloads/');
      final wa = lp.contains('whatsapp');

      CardKind? k;
      if (ext == '.apk' && e.size >= _mb) {
        k = CardKind.apk;
      } else if (wa && lp.contains('/sent/') && e.size >= _mb) {
        k = CardKind.sent;
      } else if (e.size >= 50 * _mb) {
        k = CardKind.big;
      } else if (lp.contains('screenshot') &&
          isMedia &&
          ageDays >= 14 &&
          e.size >= 200 * 1024) {
        k = CardKind.screenshot;
      } else if (inDownloads && ageDays >= 30 && e.size >= _mb) {
        k = _arcExt.contains(ext) ? CardKind.archive : CardKind.download;
      } else if (wa && ageDays >= 60 && e.size >= _mb) {
        k = CardKind.whatsapp;
      }
      if (k == null) continue;
      cards.add(<Object>[
        k.index,
        e.size,
        [
          <Object>[e.path, e.size, e.ms],
        ],
      ]);
    }

    cards.sort((x, y) => (y[1] as int).compareTo(x[1] as int));
    final cardsOut = cards.take(400).toList();

    junk.sort((x, y) => (y[1] as int).compareTo(x[1] as int));
    send.send(<Object>['done', cardsOut, junk, seen]);
  } catch (_) {
    send.send(<Object>['error', 'Scan poora nahi ho saka']);
  }
}
