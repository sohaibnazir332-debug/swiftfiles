import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;

import '../core/theme.dart';
import '../providers/browser_provider.dart';
import '../providers/settings_provider.dart';

/// "Jaldi Jao": Bookmarks, History (haal hi ke folders) aur Jagah (Download, DCIM...)
/// ek hi bottom sheet mein.
Future<void> showQuickAccess(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const QuickAccessSheet(),
  );
}

class QuickAccessSheet extends ConsumerWidget {
  const QuickAccessSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final cur = ref.watch(browserProvider.select((s) => s.path));
    final fs = ref.read(fileServiceProvider);
    final n = ref.read(settingsProvider.notifier);
    final root = fs.root.path;
    final marked = settings.bookmarks.contains(cur);
    final height = MediaQuery.of(context).size.height * 0.78;

    String nameOf(String path) => path == root ? 'Home' : p.basename(path);

    Widget row({
      required String path,
      Widget? trailing,
      IconData icon = Icons.folder_rounded,
    }) {
      final exists = Directory(path).existsSync();
      return ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: AppColors.skySoft,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(
            icon,
            color: exists ? AppColors.skyDark : AppColors.muted,
          ),
        ),
        title: Text(
          nameOf(path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: exists ? AppColors.ink : AppColors.muted,
          ),
        ),
        subtitle: Text(
          exists ? path : 'Ye folder ab nahi hai',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12, color: AppColors.muted),
        ),
        trailing: trailing,
        onTap: !exists
            ? null
            : () {
                Navigator.of(context).pop();
                ref.read(browserProvider.notifier).open(path);
              },
      );
    }

    Widget empty(IconData icon, String text) => Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 48, color: AppColors.sky),
                const SizedBox(height: 10),
                Text(
                  text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.muted, height: 1.4),
                ),
              ],
            ),
          ),
        );

    // ---- Bookmarks ----
    final bookmarks = settings.bookmarks;
    final bookmarkTab = Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 10, 4, 4),
          child: FilledButton.icon(
            onPressed: () => n.toggleBookmark(cur),
            icon: Icon(
              marked ? Icons.bookmark_remove_rounded : Icons.bookmark_add_rounded,
            ),
            label: Text(
              marked
                  ? '"${nameOf(cur)}" ka bookmark hatayein'
                  : '"${nameOf(cur)}" ko bookmark karein',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            style: FilledButton.styleFrom(
              minimumSize: const Size(double.infinity, 48),
            ),
          ),
        ),
        Expanded(
          child: bookmarks.isEmpty
              ? empty(
                  Icons.bookmarks_outlined,
                  'Abhi koi bookmark nahi.\nJis folder mein hain use upar wale button se bookmark karein.',
                )
              : ListView(
                  children: [
                    for (final b in bookmarks)
                      row(
                        path: b,
                        icon: Icons.bookmark_rounded,
                        trailing: IconButton(
                          tooltip: 'Hatayein',
                          icon: const Icon(Icons.close_rounded, color: AppColors.muted),
                          onPressed: () => n.toggleBookmark(b),
                        ),
                      ),
                  ],
                ),
        ),
      ],
    );

    // ---- History ----
    final history = settings.history.where((h) => Directory(h).existsSync()).toList();
    final historyTab = history.isEmpty
        ? empty(Icons.history_rounded, 'Abhi koi history nahi.\nJo folders aap kholenge yahan aate jayenge.')
        : Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: n.clearHistory,
                  icon: const Icon(Icons.delete_sweep_outlined, size: 20),
                  label: const Text('History saaf karein'),
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    for (final h in history)
                      row(
                        path: h,
                        icon: Icons.history_rounded,
                        trailing: IconButton(
                          tooltip: 'Bookmark',
                          icon: Icon(
                            settings.bookmarks.contains(h)
                                ? Icons.bookmark_rounded
                                : Icons.bookmark_border_rounded,
                            color: AppColors.skyDark,
                          ),
                          onPressed: () => n.toggleBookmark(h),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          );

    // ---- Jagah ----
    final places = fs.quickLocations();
    final placesTab = ListView(
      padding: const EdgeInsets.only(top: 8),
      children: [for (final l in places) row(path: l.path)],
    );

    return Container(
      height: height,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            Container(
              width: 44,
              height: 5,
              decoration: BoxDecoration(
                color: AppColors.skySoft,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 14),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Jaldi Jao',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
            ),
            const TabBar(
              labelColor: AppColors.skyDark,
              unselectedLabelColor: AppColors.muted,
              indicatorColor: AppColors.skyDark,
              labelStyle: TextStyle(fontWeight: FontWeight.w800),
              tabs: [
                Tab(text: 'Bookmarks'),
                Tab(text: 'History'),
                Tab(text: 'Jagah'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [bookmarkTab, historyTab, placesTab],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
