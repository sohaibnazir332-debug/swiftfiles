import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;

import '../core/format.dart';
import '../core/theme.dart';
import '../providers/browser_provider.dart';
import '../providers/settings_provider.dart';
import '../providers/swipe_provider.dart';
import '../services/file_service.dart';
import '../services/storage_info.dart';
import '../services/swipe_service.dart';
import 'optimizer_screen.dart';

enum _Phase { scanning, goal, swipe, review, done }

enum _Act { delete, keep, star }

class _Decision {
  _Decision(this.card, this.act, this.keepIdx);
  final SwipeCard card;
  _Act act;
  final int keepIdx;
}

const _amber = Color(0xFFFFB300);
const _imgExt = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp'};
const _vidExt = {'.mp4', '.mkv', '.3gp', '.mov', '.avi', '.webm', '.m4v'};
const _audExt = {'.mp3', '.m4a', '.aac', '.ogg', '.opus', '.wav', '.amr'};
const _arcExt = {'.zip', '.rar', '.7z', '.tar', '.gz'};

IconData _iconFor(String path) {
  final e = p.extension(path).toLowerCase();
  if (_imgExt.contains(e)) return Icons.image_rounded;
  if (_vidExt.contains(e)) return Icons.play_circle_fill_rounded;
  if (_audExt.contains(e)) return Icons.music_note_rounded;
  if (_arcExt.contains(e)) return Icons.folder_zip_rounded;
  if (e == '.apk') return Icons.android_rounded;
  if (e == '.pdf') return Icons.picture_as_pdf_rounded;
  return Icons.insert_drive_file_rounded;
}

String _kindLabel(CardKind k) => switch (k) {
      CardKind.dup => 'Duplicate',
      CardKind.apk => 'Purani APK',
      CardKind.sent => 'WhatsApp bheji',
      CardKind.big => 'Bahut badi file',
      CardKind.screenshot => 'Purana screenshot',
      CardKind.download => 'Purani download',
      CardKind.whatsapp => 'WhatsApp media',
      CardKind.archive => 'Purani ZIP / RAR',
    };

/// File kis app / jagah se aayi: folder ke naam se andaza (pakka nahi, par aksar sahi).
String? _sourceOf(String path) {
  final l = path.toLowerCase().replaceAll('\\', '/');
  bool has(String s) => l.contains(s);
  if (has('whatsapp business')) return 'WhatsApp Business';
  if (has('whatsapp')) {
    if (has('.statuses')) return 'WhatsApp Status';
    if (has('/sent/')) return 'WhatsApp (aap ne bheji)';
    return 'WhatsApp';
  }
  if (has('telegram')) return 'Telegram';
  if (has('instagram')) return 'Instagram';
  if (has('messenger')) return 'Messenger';
  if (has('facebook') || has('/fb_')) return 'Facebook';
  if (has('snapchat')) return 'Snapchat';
  if (has('tiktok') || has('musically')) return 'TikTok';
  if (has('twitter')) return 'Twitter / X';
  if (has('shareit')) return 'SHAREit';
  if (has('xender')) return 'Xender';
  if (has('bluetooth')) return 'Bluetooth';
  if (has('capcut') || has('inshot') || has('kinemaster')) {
    return 'Video editor app';
  }
  if (has('screenrecord') || has('screen recording')) return 'Screen recording';
  if (has('screenshot')) return 'Screenshot';
  if (has('dcim/camera') || has('/camera/')) return 'Phone camera';
  if (has('/download/') || has('/downloads/')) return 'Download (browser / app)';
  return null;
}

String? _sourceOfCard(SwipeCard c) {
  final set = c.files.map((f) => _sourceOf(f.path)).whereType<String>().toSet();
  return set.isEmpty ? null : set.join(' + ');
}

/// "4 mahine purani" / "aaj ki"
String _ago(DateTime d) {
  final days = DateTime.now().difference(d).inDays;
  if (days < 1) return 'aaj ki';
  if (days < 30) return '$days din purani';
  if (days < 365) return '${days ~/ 30} mahine purani';
  return '${days ~/ 365} saal purani';
}

String _reason(SwipeCard c) {
  final f = c.files.first;
  final ago = _ago(f.modified);
  return switch (c.kind) {
    CardKind.dup =>
      'Bilkul ek jaisi ${c.files.length} copies hain. Jo rakhni hai us par tap karein, baaqi hat jayengi.',
    CardKind.apk =>
      'Ye installer (APK) hai. App install ho chuki ho to ab is file ki zaroorat nahi.',
    CardKind.sent =>
      'WhatsApp mein aap ne bheji thi. Asli file aksar gallery mein bhi hoti hai.',
    CardKind.big => 'Ye $ago file hai aur bahut jagah gher rahi hai.',
    CardKind.screenshot => 'Ye $ago screenshot hai.',
    CardKind.download => 'Downloads mein padi hai. Ye $ago file hai.',
    CardKind.whatsapp => 'WhatsApp se aayi thi. Ye $ago media hai.',
    CardKind.archive =>
      'Ye $ago ZIP/RAR hai. Agar extract kar chuke hain to ab faltu hai.',
  };
}

/// "Ek Swipe Saaf": goal batao, cards swipe karo, ek baar mein saaf.
class SwipeCleanScreen extends ConsumerStatefulWidget {
  const SwipeCleanScreen({super.key});

  @override
  ConsumerState<SwipeCleanScreen> createState() => _SwipeCleanScreenState();
}

class _SwipeCleanScreenState extends ConsumerState<SwipeCleanScreen>
    with SingleTickerProviderStateMixin {
  late final FileService _fs;
  late final SwipeService _svc;
  late final SwipeStore _store;
  late final AnimationController _anim;

  _Phase _phase = _Phase.scanning;
  SwipeScanResult? _result;
  SwipeProgress? _progress;
  String? _error;
  StorageStats? _before;
  StorageStats? _after;

  // goal
  int _goal = -1; // -1 = abhi chuna nahi, 0 = jitna mile
  bool _junkBusy = false;
  int _junkFreed = -1;

  // swipe
  List<SwipeCard> _queue = [];
  int _index = 0;
  final List<_Decision> _decisions = [];
  final Map<SwipeCard, int> _pick = {};
  Offset _drag = Offset.zero;
  Offset _from = Offset.zero;
  Offset _to = Offset.zero;
  _Act? _pendingAct;
  bool _goalShown = false;

  // delete + undo
  bool _busy = false;
  final List<TrashRecord> _records = [];
  int _freed = 0;
  int _failed = 0;
  int _secs = 10;
  Timer? _undoTimer;
  bool _purging = false;
  bool _purged = false;
  bool _undone = false;

  @override
  void initState() {
    super.initState();
    _fs = ref.read(fileServiceProvider);
    _svc = ref.read(swipeServiceProvider);
    _store = ref.read(swipeStoreProvider);
    _before = ref.read(storageStatsProvider).valueOrNull;
    _anim = AnimationController(vsync: this);
    _anim.addListener(() {
      final t = Curves.easeOut.transform(_anim.value);
      setState(() => _drag = Offset.lerp(_from, _to, t) ?? _to);
    });
    _anim.addStatusListener((s) {
      if (s != AnimationStatus.completed) return;
      final act = _pendingAct;
      _pendingAct = null;
      if (act != null) _apply(act);
    });
    _scan();
  }

  @override
  void dispose() {
    _undoTimer?.cancel();
    _anim.dispose();
    _svc.cancel();
    if (!_purged && _records.isNotEmpty) {
      for (final r in _records) {
        unawaited(_fs.purge(r).catchError((_) {}));
      }
    }
    super.dispose();
  }

  // ------------------------------------------------------------------- scan

  Future<void> _scan() async {
    setState(() {
      _phase = _Phase.scanning;
      _error = null;
      _progress = const SwipeProgress('Shuru ho raha hai', 0);
    });
    try {
      final r = await _svc.scan(
        favorites: ref.read(settingsProvider).favorites,
        kept: _store.kept,
        includeWhatsApp: _store.includeWhatsApp,
        onProgress: (pr) {
          if (mounted) setState(() => _progress = pr);
        },
      );
      if (!mounted) return;
      setState(() {
        _result = r;
        _phase = _Phase.goal;
        if (_goal < 0) {
          final gb = 1024 * 1024 * 1024;
          _goal = r.reclaimable >= 2 * gb ? 2 * gb : 0;
        }
      });
    } catch (e) {
      if (!mounted) return;
      final cancelled = e is FileOpException && e.message == 'cancelled';
      if (cancelled) return;
      setState(() => _error = 'Scan poora nahi ho saka');
    }
  }

  Future<void> _cleanJunk() async {
    final r = _result;
    if (r == null || _junkBusy) return;
    setState(() => _junkBusy = true);
    final freed = await _svc.deleteJunk(r.junk);
    _store.addFreed(freed);
    if (!mounted) return;
    ref.invalidate(storageStatsProvider);
    StorageStats? s;
    try {
      s = await ref.read(storageStatsProvider.future);
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _junkBusy = false;
      _junkFreed = freed;
      if (s != null) _before = s;
    });
  }

  void _start() {
    final r = _result;
    if (r == null || r.cards.isEmpty) return;
    setState(() {
      _queue = List.of(r.cards);
      _index = 0;
      _decisions.clear();
      _pick.clear();
      _goalShown = false;
      _drag = Offset.zero;
      _phase = _Phase.swipe;
    });
  }

  // ------------------------------------------------------------------ swipe

  int get _binBytes => _decisions
      .where((d) => d.act == _Act.delete)
      .fold(0, (s, d) => s + d.card.reclaim);

  List<_Decision> get _deletes =>
      _decisions.where((d) => d.act == _Act.delete).toList();

  void _fly(_Act act) {
    if (_phase != _Phase.swipe || _index >= _queue.length) return;
    if (_pendingAct != null) return;
    final size = MediaQuery.of(context).size;
    final to = switch (act) {
      _Act.delete => Offset(-size.width * 1.3, _drag.dy),
      _Act.keep => Offset(size.width * 1.3, _drag.dy),
      _Act.star => Offset(_drag.dx, -size.height),
    };
    _run(to, act);
  }

  void _run(Offset to, [_Act? act]) {
    _from = _drag;
    _to = to;
    _pendingAct = act;
    _anim.duration = Duration(milliseconds: act == null ? 200 : 240);
    _anim.forward(from: 0);
  }

  void _apply(_Act act) {
    if (_index >= _queue.length) return;
    final card = _queue[_index];
    final pick = _pick[card] ?? 0;
    final paths = card.files.map((f) => f.path).toList();
    _decisions.add(_Decision(card, act, pick));
    if (act == _Act.keep) {
      _store.addKept(paths);
    } else if (act == _Act.star) {
      _store.addKept(paths);
      ref.read(settingsProvider.notifier).setFavorites([paths[pick]], add: true);
    }
    HapticFeedback.selectionClick();
    setState(() {
      _index++;
      _drag = Offset.zero;
      if (_index >= _queue.length) _phase = _Phase.review;
    });
    _maybeGoalToast();
  }

  void _maybeGoalToast() {
    if (_goalShown || _goal <= 0 || _binBytes < _goal) return;
    _goalShown = true;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    final c = m.showSnackBar(
      SnackBar(
        content: Text('🎯 Target poora! Bin mein ${formatSize(_binBytes)} hai.'),
        action: SnackBarAction(
          label: 'Saaf karein',
          textColor: Colors.white,
          onPressed: () => setState(() => _phase = _Phase.review),
        ),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        backgroundColor: AppColors.ink,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
    Future.delayed(const Duration(seconds: 5), c.close);
  }

  void _undoLast() {
    if (_decisions.isEmpty || _pendingAct != null) return;
    final d = _decisions.removeLast();
    final paths = d.card.files.map((f) => f.path).toList();
    if (d.act == _Act.keep) {
      _store.removeKept(paths);
    } else if (d.act == _Act.star) {
      _store.removeKept(paths);
      ref
          .read(settingsProvider.notifier)
          .setFavorites([paths[d.keepIdx]], add: false);
    }
    setState(() {
      _index = (_index - 1).clamp(0, _queue.length);
      _drag = Offset.zero;
      _phase = _Phase.swipe;
    });
  }

  void _onPanEnd(DragEndDetails d, double width) {
    if (_pendingAct != null) return;
    final v = d.velocity.pixelsPerSecond;
    final th = width * 0.28;
    final dx = _drag.dx;
    final dy = _drag.dy;
    if (dy < -th && dy.abs() > dx.abs()) {
      _fly(_Act.star);
    } else if (dx < -th || (v.dx < -900 && dx < -20)) {
      _fly(_Act.delete);
    } else if (dx > th || (v.dx > 900 && dx > 20)) {
      _fly(_Act.keep);
    } else {
      _run(Offset.zero);
    }
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (_phase != _Phase.swipe || e is! KeyDownEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowLeft || k == LogicalKeyboardKey.delete) {
      _fly(_Act.delete);
    } else if (k == LogicalKeyboardKey.arrowRight) {
      _fly(_Act.keep);
    } else if (k == LogicalKeyboardKey.arrowUp) {
      _fly(_Act.star);
    } else if (k == LogicalKeyboardKey.keyZ || k == LogicalKeyboardKey.backspace) {
      _undoLast();
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  // ----------------------------------------------------------------- delete

  Future<void> _confirmDelete() async {
    if (_busy) return;
    final tasks = <SwipeFile>[];
    for (final d in _deletes) {
      tasks.addAll(d.card.toDelete(d.keepIdx));
    }
    if (tasks.isEmpty) return;
    setState(() => _busy = true);
    var freed = 0;
    var failed = 0;
    for (final f in tasks) {
      try {
        _records.add(await _fs.trash(f.path));
        freed += f.size;
      } catch (_) {
        failed++;
      }
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _freed = freed;
      _failed = failed;
      _secs = 10;
      _purged = _records.isEmpty;
      _phase = _Phase.done;
    });
    if (_records.isEmpty) return;
    _undoTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (_secs <= 1) {
        t.cancel();
        setState(() => _secs = 0);
        _finishDeletion();
      } else {
        setState(() => _secs--);
      }
    });
  }

  /// Undo ka waqt khatam: files hamesha ke liye delete, jagah asal mein khali.
  Future<void> _finishDeletion() async {
    _undoTimer?.cancel();
    if (_purged || _purging) return;
    if (mounted) setState(() => _purging = true);
    for (final r in _records) {
      try {
        await _fs.purge(r);
      } catch (_) {}
    }
    _purged = true;
    _store.addFreed(_freed);
    StorageStats? s;
    if (mounted) {
      ref.invalidate(storageStatsProvider);
      try {
        s = await ref.read(storageStatsProvider.future);
      } catch (_) {}
    }
    if (mounted) {
      setState(() {
        _after = s;
        _purging = false;
      });
    }
  }

  Future<void> _undoAll() async {
    _undoTimer?.cancel();
    if (_purged || _purging) return;
    var back = 0;
    for (final r in _records) {
      try {
        await _fs.restore(r);
        back++;
      } catch (_) {}
    }
    _records.clear();
    _purged = true;
    if (!mounted) return;
    setState(() {
      _undone = true;
      _freed = 0;
    });
    if (back > 0) ref.invalidate(storageStatsProvider);
  }

  Future<void> _close() async {
    await _finishDeletion();
    if (mounted) Navigator.of(context).pop();
  }

  // ------------------------------------------------------------------- UI

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _records.isEmpty || _purged,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await _close();
      },
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: switch (_phase) {
          _Phase.scanning => _scanningView(),
          _Phase.goal => _goalView(),
          _Phase.swipe => _swipeView(),
          _Phase.review => _reviewView(),
          _Phase.done => _doneView(),
        },
      ),
    );
  }

  Widget _header(
    String title, {
    String? sub,
    Widget? trailing,
    Widget? bottom,
    bool back = true,
  }) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.sky, AppColors.skyDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 4, 16, 16),
          child: Column(
            children: [
              Row(
                children: [
                  if (back)
                    IconButton(
                      icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                      onPressed: () => Navigator.of(context).maybePop(),
                    )
                  else
                    const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (sub != null)
                          Text(
                            sub,
                            style: const TextStyle(color: Colors.white70, fontSize: 13),
                          ),
                      ],
                    ),
                  ),
                  if (trailing != null) trailing,
                ],
              ),
              if (bottom != null)
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 10),
                  child: bottom,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child, EdgeInsets? padding}) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(color: Color(0x141E88E5), blurRadius: 14, offset: Offset(0, 5)),
        ],
      ),
      child: child,
    );
  }

  // --------------------------------------------------------------- scanning

  Widget _scanningView() {
    final pr = _progress;
    return Column(
      children: [
        _header('Swipe Saaf', sub: 'Phone ko scan kar rahe hain'),
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: _error != null
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            size: 56, color: AppColors.danger),
                        const SizedBox(height: 12),
                        Text(_error!,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _scan, child: const Text('Dobara try karein')),
                      ],
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(
                          width: 84,
                          height: 84,
                          child: CircularProgressIndicator(strokeWidth: 7),
                        ),
                        const SizedBox(height: 22),
                        const Text(
                          'Faltu cheezein dhoondh rahe hain…',
                          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          pr == null
                              ? ''
                              : '${pr.phase}${pr.done > 0 ? ': ${pr.done}' : ''}',
                          style: const TextStyle(color: AppColors.muted),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Sirf padh rahe hain, abhi kuch delete nahi hota.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.muted, fontSize: 12.5),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------------- goal

  ({int n, int bytes}) _plan(int goal) {
    var sum = 0;
    var n = 0;
    for (final c in _result!.cards) {
      sum += c.reclaim;
      n++;
      if (goal > 0 && sum >= goal) break;
    }
    return (n: n, bytes: sum);
  }

  Widget _goalChip(String label, int value) {
    final sel = _goal == value;
    return ChoiceChip(
      label: Text(label),
      selected: sel,
      showCheckmark: false,
      onSelected: (_) => setState(() => _goal = value),
      selectedColor: AppColors.skyDark,
      backgroundColor: Colors.white,
      side: const BorderSide(color: AppColors.skySoft),
      labelStyle: TextStyle(
        color: sel ? Colors.white : AppColors.ink,
        fontWeight: FontWeight.w800,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    );
  }

  Widget _goalView() {
    final r = _result!;
    final stats = ref.watch(storageStatsProvider).valueOrNull ?? _before;
    const gb = 1024 * 1024 * 1024;
    final goals = <int>[for (final g in [1, 2, 5, 10]) if (g * gb <= r.reclaimable) g * gb];
    final plan = _plan(_goal < 0 ? 0 : _goal);
    final secs = plan.n * 5;
    final time = secs < 60 ? '$secs second' : '${(secs / 60).ceil()} minute';
    final totalFreed = _store.totalFreed;

    return Column(
      children: [
        _header(
          'Ek Swipe Saaf',
          sub: stats == null
              ? 'Pehle batayein kitni jagah chahiye'
              : '${formatSize(stats.free)} khali • ${(stats.fraction * 100).round()}% bhara',
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            children: [
              if (r.junkBytes > 0) ...[
                _card(
                  child: Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          color: AppColors.skySoft,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(Icons.cleaning_services_rounded,
                            color: AppColors.skyDark),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _junkFreed >= 0
                                  ? '✓ ${formatSize(_junkFreed)} faltu saaf'
                                  : 'Faltu files: ${formatSize(r.junkBytes)}',
                              style: const TextStyle(
                                  fontSize: 15.5, fontWeight: FontWeight.w800),
                            ),
                            const SizedBox(height: 2),
                            const Text(
                              'Temp, adhoore downloads, khali folders',
                              style: TextStyle(fontSize: 12.5, color: AppColors.muted),
                            ),
                          ],
                        ),
                      ),
                      if (_junkFreed < 0)
                        FilledButton(
                          onPressed: _junkBusy ? null : _cleanJunk,
                          style: FilledButton.styleFrom(
                            minimumSize: const Size(0, 42),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                          ),
                          child: _junkBusy
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2.5, color: Colors.white),
                                )
                              : const Text('Saaf'),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
              ],
              _card(
                padding: const EdgeInsets.fromLTRB(16, 6, 8, 6),
                child: SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _store.includeWhatsApp,
                  onChanged: (v) {
                    _store.setIncludeWhatsApp(v);
                    _scan();
                  },
                  title: const Text(
                    'WhatsApp media bhi dhoondo',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'Band rakhna safe hai: WhatsApp mein star ki hui photo/video '
                    'is app ko nahi dikhti.',
                    style: TextStyle(fontSize: 12.5),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              if (r.cards.isEmpty)
                _card(
                  padding: const EdgeInsets.all(24),
                  child: const Column(
                    children: [
                      Icon(Icons.celebration_rounded, size: 54, color: AppColors.sky),
                      SizedBox(height: 10),
                      Text(
                        'Phone saaf hai! 🎉',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Koi duplicate, badi ya purani faltu file nahi mili.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.muted),
                      ),
                    ],
                  ),
                )
              else ...[
                const Text(
                  'Kitni jagah chahiye?',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final g in goals) _goalChip('${g ~/ gb} GB', g),
                    _goalChip('Jitna ho sake', 0),
                  ],
                ),
                const SizedBox(height: 18),
                _card(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${plan.n} cards',
                        style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: AppColors.skyDark,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Sirf itne dekhne hain (lagbhag $time). '
                        'Agar sab delete karein to ${formatSize(plan.bytes)} khali.',
                        style: const TextStyle(fontSize: 14, color: AppColors.ink),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        '⬅️ delete   •   ➡️ rakho   •   ⬆️ ⭐ favorite\n'
                        'Kuch bhi foran delete nahi hota. Aakhir mein ek baar poochhenge, phir 10 second Undo.',
                        style: TextStyle(fontSize: 12.5, color: AppColors.muted, height: 1.4),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: _start,
                  icon: const Icon(Icons.swipe_rounded),
                  label: const Text('Shuru karein'),
                  style: FilledButton.styleFrom(minimumSize: const Size(0, 54)),
                ),
              ],
              const SizedBox(height: 14),
              Center(
                child: TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const OptimizerScreen()),
                  ),
                  child: const Text('Puri list dekhein (Duplicates / Badi files)'),
                ),
              ),
              if (totalFreed > 0)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      '🏆 Ab tak aap ne ${formatSize(totalFreed)} khali kiya',
                      style: const TextStyle(
                          color: AppColors.muted, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------------ swipe

  Widget _binChip() {
    final n = _deletes.length;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => setState(() => _phase = _Phase.review),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(60),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 18),
            const SizedBox(width: 6),
            Text(
              '$n • ${formatSize(_binBytes)}',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
    );
  }

  Widget _goalBar() {
    final bin = _binBytes;
    if (_goal <= 0) {
      return Text(
        'Bin mein: ${formatSize(bin)}',
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
      );
    }
    final v = (bin / _goal).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: v,
            minHeight: 9,
            color: Colors.white,
            backgroundColor: Colors.white.withAlpha(70),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Target ${formatSize(_goal)} • ${formatSize(bin)} ho gaya',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5),
        ),
      ],
    );
  }

  Widget _roundBtn(IconData icon, Color color, double size, VoidCallback? onTap, String label) {
    final on = onTap != null;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: Colors.white,
          elevation: 3,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(
              width: size,
              height: size,
              child: Icon(icon, color: on ? color : AppColors.muted.withAlpha(110), size: size * 0.5),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
      ],
    );
  }

  Widget _stamp(String text, Color color, double opacity, Alignment al) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Align(
          alignment: al,
          child: Opacity(
            opacity: opacity.clamp(0.0, 1.0),
            child: Container(
              margin: const EdgeInsets.all(22),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: color, width: 4),
                borderRadius: BorderRadius.circular(12),
                color: Colors.white.withAlpha(200),
              ),
              child: Text(
                text,
                style: TextStyle(color: color, fontSize: 26, fontWeight: FontWeight.w900),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _swipeView() {
    if (_index >= _queue.length) return const SizedBox.shrink();
    final cur = _queue[_index];
    final next = _index + 1 < _queue.length ? _queue[_index + 1] : null;
    final root = _fs.root.path;

    return Focus(
      autofocus: true,
      onKeyEvent: _onKey,
      child: Column(
        children: [
          _header(
            'Ek Swipe Saaf',
            sub: 'Card ${_index + 1} / ${_queue.length}',
            trailing: _binChip(),
            bottom: _goalBar(),
          ),
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
                  child: LayoutBuilder(
                    builder: (context, c) {
                      final w = c.maxWidth;
                      final th = w * 0.28;
                      final t = (_drag.distance / th).clamp(0.0, 1.0);
                      final dxAbs = _drag.dx.abs();
                      final dyUp = -_drag.dy;
                      final starDominant = dyUp > 0 && dyUp > dxAbs;
                      return Stack(
                        children: [
                          if (next != null)
                            Positioned.fill(
                              child: Transform.scale(
                                scale: 0.94 + 0.06 * t,
                                child: IgnorePointer(
                                  child: _CardFace(
                                    key: ValueKey(next),
                                    card: next,
                                    rootPath: root,
                                    pick: _pick[next] ?? 0,
                                    onPick: (_) {},
                                    onOpen: (_) {},
                                  ),
                                ),
                              ),
                            ),
                          Positioned.fill(
                            child: GestureDetector(
                              onPanStart: (_) {
                                if (_pendingAct == null) _anim.stop();
                              },
                              onPanUpdate: (d) {
                                if (_pendingAct != null) return;
                                setState(() => _drag += d.delta);
                              },
                              onPanEnd: (d) => _onPanEnd(d, w),
                              child: Transform.translate(
                                offset: _drag,
                                child: Transform.rotate(
                                  angle: _drag.dx / w * 0.3,
                                  child: Stack(
                                    children: [
                                      Positioned.fill(
                                        child: _CardFace(
                                          key: ValueKey(cur),
                                          card: cur,
                                          rootPath: root,
                                          pick: _pick[cur] ?? 0,
                                          onPick: (i) => setState(() => _pick[cur] = i),
                                          onOpen: (path) => OpenFilex.open(path),
                                        ),
                                      ),
                                      _stamp(
                                        'DELETE',
                                        AppColors.danger,
                                        starDominant ? 0 : -_drag.dx / th,
                                        Alignment.topRight,
                                      ),
                                      _stamp(
                                        'RAKHO',
                                        AppColors.success,
                                        starDominant ? 0 : _drag.dx / th,
                                        Alignment.topLeft,
                                      ),
                                      _stamp(
                                        '⭐ FAVORITE',
                                        _amber,
                                        starDominant ? dyUp / th : 0,
                                        Alignment.bottomCenter,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _roundBtn(Icons.undo_rounded, AppColors.skyDark, 46,
                    _decisions.isEmpty ? null : _undoLast, 'Wapas'),
                _roundBtn(Icons.close_rounded, AppColors.danger, 66,
                    () => _fly(_Act.delete), 'Delete'),
                _roundBtn(Icons.star_rounded, _amber, 46, () => _fly(_Act.star), 'Favorite'),
                _roundBtn(Icons.check_rounded, AppColors.success, 66,
                    () => _fly(_Act.keep), 'Rakho'),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 8),
              child: Text(
                Platform.isWindows
                    ? 'Keyboard: ← delete   → rakho   ↑ favorite   Z wapas'
                    : 'Card ko left / right / upar swipe karein',
                style: const TextStyle(fontSize: 12, color: AppColors.muted),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ----------------------------------------------------------------- review

  Widget _thumb(String path, {double size = 50}) {
    final ext = p.extension(path).toLowerCase();
    Widget icon() => Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: AppColors.skySoft,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(_iconFor(path), color: AppColors.skyDark),
        );
    if (!_imgExt.contains(ext)) return icon();
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.file(
        File(path),
        width: size,
        height: size,
        fit: BoxFit.cover,
        cacheWidth: 140,
        errorBuilder: (_, __, ___) => icon(),
      ),
    );
  }

  Widget _reviewView() {
    final dels = _deletes;
    final kept = _decisions.where((d) => d.act == _Act.keep).length;
    final starred = _decisions.where((d) => d.act == _Act.star).length;
    final bytes = _binBytes;
    final left = _queue.length - _index;

    return Column(
      children: [
        _header(
          'Bin',
          sub: '${dels.length} cheezein • ${formatSize(bytes)}',
        ),
        Expanded(
          child: dels.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.inventory_2_outlined,
                            size: 56, color: AppColors.sky),
                        const SizedBox(height: 10),
                        const Text(
                          'Bin khali hai',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Aap ne $kept rakhi, $starred favorite kiin.',
                          style: const TextStyle(color: AppColors.muted),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                  itemCount: dels.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final d = dels[i];
                    final f = d.card.toDelete(d.keepIdx).first;
                    return Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          _thumb(f.path),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  p.basename(f.path),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700, fontSize: 14.5),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${d.card.isDup ? 'Duplicate' : _kindLabel(d.card.kind)}'
                                  ' • ${formatSize(d.card.reclaim)}'
                                  '${_sourceOfCard(d.card) != null ? ' • ${_sourceOfCard(d.card)}' : ''}',
                                  style: const TextStyle(
                                      fontSize: 12.5, color: AppColors.muted),
                                ),
                              ],
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              final paths =
                                  d.card.files.map((x) => x.path).toList();
                              _store.addKept(paths);
                              setState(() => d.act = _Act.keep);
                            },
                            child: const Text('Rakho'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (dels.isNotEmpty)
                  FilledButton.icon(
                    onPressed: _busy ? null : _confirmDelete,
                    icon: _busy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2.5, color: Colors.white),
                          )
                        : const Icon(Icons.delete_forever_rounded),
                    label: Text('${formatSize(bytes)} khali karein'),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.danger,
                      minimumSize: const Size(double.infinity, 54),
                    ),
                  ),
                if (left > 0)
                  TextButton(
                    onPressed: () => setState(() => _phase = _Phase.swipe),
                    child: Text('Aur cards dekhein ($left baaqi)'),
                  )
                else if (dels.isEmpty)
                  FilledButton(
                    onPressed: () => Navigator.of(context).maybePop(),
                    child: const Text('Ho gaya'),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------------- done

  Widget _doneView() {
    final b = _before;
    final a = _after;
    final shown = a ?? b;
    final total = _store.totalFreed;

    Widget ring() {
      if (shown == null) return const SizedBox.shrink();
      final f = shown.fraction;
      final color = f > 0.9
          ? AppColors.danger
          : (f > 0.75 ? _amber : AppColors.sky);
      return Column(
        children: [
          SizedBox(
            width: 120,
            height: 120,
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: b?.fraction ?? f, end: f),
              duration: const Duration(milliseconds: 1200),
              curve: Curves.easeOutCubic,
              builder: (_, v, __) => Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircularProgressIndicator(
                      value: v,
                      strokeWidth: 11,
                      color: color,
                      backgroundColor: AppColors.skySoft,
                    ),
                  ),
                  Text(
                    '${(v * 100).round()}%',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            a == null
                ? 'Storage update ho raha hai…'
                : 'Ab ${formatSize(a.free)} khali hai',
            style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600),
          ),
        ],
      );
    }

    final dels = _deletes.length;
    final kept = _decisions.where((d) => d.act == _Act.keep).length;
    final starred = _decisions.where((d) => d.act == _Act.star).length;

    return Column(
      children: [
        _header('Ho gaya!', back: false),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
            children: [
              Center(
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0.3, end: 1),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.elasticOut,
                  builder: (_, v, child) => Transform.scale(scale: v, child: child),
                  child: Icon(
                    _undone ? Icons.undo_rounded : Icons.celebration_rounded,
                    size: 64,
                    color: _undone ? AppColors.muted : AppColors.sky,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: _undone
                    ? const Text(
                        'Sab wapas aa gaya',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                      )
                    : TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: _freed.toDouble()),
                        duration: const Duration(milliseconds: 1300),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, __) => Text(
                          '+${formatSize(v.round())}',
                          style: const TextStyle(
                            fontSize: 44,
                            fontWeight: FontWeight.w900,
                            color: AppColors.skyDark,
                          ),
                        ),
                      ),
              ),
              if (!_undone)
                const Center(
                  child: Text('khali ho gaya', style: TextStyle(color: AppColors.muted)),
                ),
              const SizedBox(height: 22),
              Center(child: ring()),
              const SizedBox(height: 22),
              _card(
                child: Column(
                  children: [
                    _statRow(Icons.delete_outline_rounded, 'Hataya', '$dels'),
                    _statRow(Icons.check_rounded, 'Rakha', '$kept'),
                    _statRow(Icons.star_rounded, 'Favorite', '$starred'),
                    if (_failed > 0)
                      _statRow(Icons.error_outline_rounded, 'Na ho saka', '$_failed'),
                    if (total > 0 && !_undone)
                      _statRow(Icons.emoji_events_rounded, 'Ab tak kul khali',
                          formatSize(total + (_purged ? 0 : _freed))),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              if (!_purged && !_purging && !_undone)
                OutlinedButton.icon(
                  onPressed: _undoAll,
                  icon: const Icon(Icons.undo_rounded),
                  label: Text('UNDO — sab wapas ($_secs)'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 52),
                    side: const BorderSide(color: AppColors.sky),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    textStyle: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              if (_purging)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('Pakka delete ho raha hai…',
                        style: TextStyle(color: AppColors.muted)),
                  ),
                ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _close,
                child: Text(_purged || _undone ? 'Ho gaya' : 'Ab pakka karein'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _statRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.skyDark),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 15))),
          Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

// =============================================================================
// Card ka chehra
// =============================================================================

class _CardFace extends StatelessWidget {
  const _CardFace({
    super.key,
    required this.card,
    required this.rootPath,
    required this.pick,
    required this.onPick,
    required this.onOpen,
  });

  final SwipeCard card;
  final String rootPath;
  final int pick;
  final void Function(int) onPick;
  final void Function(String) onOpen;

  Widget _iconBox(String path) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.skySoft, Colors.white],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Icon(_iconFor(path), size: 84, color: AppColors.skyDark),
      ),
    );
  }

  Widget _image(String path) {
    final ext = p.extension(path).toLowerCase();
    if (!_imgExt.contains(ext)) return _iconBox(path);
    return Image.file(
      File(path),
      fit: BoxFit.cover,
      cacheWidth: 800,
      gaplessPlayback: true,
      errorBuilder: (_, __, ___) => _iconBox(path),
    );
  }

  Widget _single() {
    final f = card.files.first;
    return Stack(
      fit: StackFit.expand,
      children: [
        _image(f.path),
        Positioned(
          right: 12,
          bottom: 12,
          child: Material(
            color: Colors.black54,
            borderRadius: BorderRadius.circular(20),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => onOpen(f.path),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.open_in_new_rounded, color: Colors.white, size: 16),
                    SizedBox(width: 6),
                    Text('Kholo',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _tile(SwipeFile f, int i) {
    final sel = i == pick;
    return GestureDetector(
      onTap: () => onPick(i),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: sel ? AppColors.skyDark : Colors.transparent,
            width: 3,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    _image(f.path),
                    Positioned(
                      top: 6,
                      left: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: sel ? AppColors.skyDark : AppColors.danger,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          sel ? 'RAKHO' : 'HATEGI',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 6, 6, 6),
              child: Column(
                children: [
                  Text(
                    p.basename(p.dirname(f.path)),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                  Text(
                    formatDate(f.modified),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: AppColors.muted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dupTiles() {
    final shown = card.files.take(3).toList();
    return Container(
      color: AppColors.skySoft,
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (var i = 0; i < shown.length; i++) ...[
            if (i > 0) const SizedBox(width: 10),
            Expanded(child: _tile(shown[i], i)),
          ],
        ],
      ),
    );
  }

  Widget _info() {
    final f = card.files.first;
    String where;
    try {
      where = p.relative(p.dirname(f.path), from: rootPath);
    } catch (_) {
      where = p.dirname(f.path);
    }
    if (where == '.' || where.isEmpty) where = 'Home';
    final extra = card.files.length - 3;
    final src = _sourceOfCard(card);
    final isWa = card.files.any((x) => x.path.toLowerCase().contains('whatsapp'));

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
      child: SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    card.isDup
                        ? '${formatSize(card.reclaim)} bachega'
                        : formatSize(card.reclaim),
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: AppColors.ink,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.skySoft,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _kindLabel(card.kind),
                    style: const TextStyle(
                      color: AppColors.skyDark,
                      fontWeight: FontWeight.w800,
                      fontSize: 12.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              p.basename(f.path),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            Text(
              '$where • ${formatDate(f.modified)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, color: AppColors.muted),
            ),
            if (src != null) ...[
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(Icons.apps_rounded, size: 17, color: AppColors.skyDark),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Kahan se: $src',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: AppColors.skyDark,
                      ),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.lightbulb_outline_rounded,
                    size: 18, color: AppColors.skyDark),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _reason(card) + (extra > 0 ? ' (+$extra aur copies bhi hategi)' : ''),
                    style: const TextStyle(fontSize: 13.5, height: 1.35),
                  ),
                ),
              ],
            ),
            if (isWa)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  '⚠️ WhatsApp ki file hai. Chat mein star ya zaroori ho to delete na karein.',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.danger,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [
          BoxShadow(color: Color(0x261E88E5), blurRadius: 22, offset: Offset(0, 10)),
        ],
      ),
      child: Column(
        children: [
          Expanded(flex: 5, child: card.isDup ? _dupTiles() : _single()),
          Expanded(flex: 4, child: _info()),
        ],
      ),
    );
  }
}
