import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;

import 'file_service.dart';
import 'web_page.dart';

/// Wireless transfer: app ke andar chhota sa local web server chalta hai.
/// Dusra device (PC/mobile) browser mein address kholta hai, PIN daalta hai,
/// aur files upload/download kar leta hai. Data sirf Wi-Fi ke andar rehta hai.
class TransferService extends ChangeNotifier {
  TransferService(this._fs);

  final FileService _fs;
  HttpServer? _server;
  int _failedPins = 0;

  bool shareAll = false; // true: poori storage browse ho sakti hai
  bool allowUpload = false; // shareAll mein PC se phone par likhna
  String? url;
  String pin = '';
  String? error;
  final List<String> received = [];

  bool get running => _server != null;
  Directory get dir => _fs.transferDir;
  Directory get _base => shareAll ? _fs.root : dir;

  Future<void> setShareAll(bool v) async {
    if (v && !await _fs.ensurePermission()) {
      error = 'Storage ki permission chahiye (Settings mein allow karein).';
      notifyListeners();
      return;
    }
    error = null;
    shareAll = v;
    if (!v) allowUpload = false;
    notifyListeners();
  }

  void setAllowUpload(bool v) {
    allowUpload = v;
    notifyListeners();
  }

  Future<void> start() async {
    if (running) return;
    error = null;
    try {
      await dir.create(recursive: true);
      pin = (1000 + Random.secure().nextInt(9000)).toString();
      _failedPins = 0;
      try {
        _server = await io.serve(_handle, InternetAddress.anyIPv4, 8080);
      } on SocketException {
        // 8080 busy ho to koi bhi khali port le lo
        _server = await io.serve(_handle, InternetAddress.anyIPv4, 0);
      }
      final ip = await _localIp();
      url = 'http://${ip ?? 'localhost'}:${_server!.port}';
    } catch (e) {
      error = 'Server start nahi hua. Wi-Fi check karein.';
      _server = null;
      url = null;
    }
    notifyListeners();
  }

  Future<void> stop() async {
    final s = _server;
    _server = null;
    url = null;
    notifyListeners();
    await s?.close(force: true);
  }

  @override
  void dispose() {
    _server?.close(force: true);
    super.dispose();
  }

  // ---------- request handling ----------

  Future<Response> _handle(Request req) async {
    final path = req.url.path;

    // Page load ke liye PIN nahi chahiye (page khud PIN maangta hai)
    if (req.method == 'GET' && path.isEmpty) {
      return Response.ok(
        kWebPage,
        headers: {'content-type': 'text/html; charset=utf-8'},
      );
    }

    if (_failedPins >= 10) {
      return Response(
        429,
        body: 'Bohat zyada galat PIN. Server band karke dobara chalayein.',
      );
    }
    final given = req.headers['x-pin'] ?? req.url.queryParameters['pin'];
    if (given != pin) {
      _failedPins++;
      return Response.forbidden('Wrong PIN');
    }
    _failedPins = 0;

    try {
      if (req.method == 'GET' && path == 'api/info') return _info();
      if (req.method == 'GET' && path == 'api/ls') return await _ls(req);
      if (req.method == 'GET' && path == 'api/tree') return await _tree(req);
      if (req.method == 'GET' && path == 'api/stat') return await _stat(req);
      if (req.method == 'GET' && path == 'get') return await _get(req);
      if (req.method == 'PUT' && path == 'put') return await _put(req);
      if (req.method == 'GET' && path == 'api/files') return await _list();
      if (req.method == 'GET' && path == 'download') return await _download(req);
      if (req.method == 'PUT' && path == 'upload') return await _upload(req);
    } catch (e) {
      return Response.internalServerError(body: 'Error: $e');
    }
    return Response.notFound('Not found');
  }

  // ---------- naya: poori storage browse + folder + resume ----------

  static const _json = {'content-type': 'application/json; charset=utf-8'};

  /// 'DCIM/Trip' jaisa relative path -> asli path (sirf _base ke andar).
  String? _resolve(String rel) {
    final parts = rel
        .split(RegExp(r'[\\/]'))
        .where((x) => x.isNotEmpty && x != '.')
        .toList();
    if (parts.any((x) => x == '..')) return null;
    if (parts.any((x) => x.startsWith('.'))) return null;
    return parts.isEmpty ? _base.path : p.joinAll([_base.path, ...parts]);
  }

  bool _hidden(String name) => name.startsWith('.') || name.endsWith('.swiftpart');

  String _cleanSeg(String s) => s.replaceAll(RegExp(r'[<>:"|?*\x00-\x1f]'), '_');

  Response _info() => Response.ok(
        jsonEncode({
          'all': shareAll,
          'up': !shareAll || allowUpload,
          'name': shareAll ? 'Phone' : 'Transfer',
        }),
        headers: _json,
      );

  Future<Response> _ls(Request req) async {
    final path = _resolve(req.url.queryParameters['path'] ?? '');
    if (path == null) return Response.forbidden('Bad path');
    final d = Directory(path);
    if (!await d.exists()) {
      if (!shareAll && path == dir.path) await dir.create(recursive: true);
      if (!await d.exists()) return Response.notFound('Folder nahi mila');
    }
    final items = <Map<String, Object>>[];
    try {
      await for (final e in d.list(followLinks: false)) {
        final name = p.basename(e.path);
        if (_hidden(name)) continue;
        try {
          final st = await e.stat();
          final isDir = st.type == FileSystemEntityType.directory;
          if (!isDir && st.type != FileSystemEntityType.file) continue;
          items.add({
            'n': name,
            'd': isDir,
            's': isDir ? 0 : st.size,
            'm': st.modified.millisecondsSinceEpoch,
          });
        } catch (_) {}
      }
    } on FileSystemException {
      return Response.forbidden('Permission nahi hai');
    }
    return Response.ok(
      jsonEncode({'path': req.url.queryParameters['path'] ?? '', 'items': items}),
      headers: _json,
    );
  }

  /// Folder ke andar ki saari files (relative path + size), zip banaye bina.
  Future<Response> _tree(Request req) async {
    final path = _resolve(req.url.queryParameters['path'] ?? '');
    if (path == null) return Response.forbidden('Bad path');
    final d = Directory(path);
    if (!await d.exists()) return Response.notFound('Folder nahi mila');
    final out = <List<Object>>[];
    await for (final e in d.list(recursive: true, followLinks: false).handleError((_) {})) {
      if (e is! File) continue;
      final r = p.relative(e.path, from: path);
      if (r.split(p.separator).any(_hidden)) continue;
      try {
        out.add([r.replaceAll('\\', '/'), await e.length()]);
      } catch (_) {}
      if (out.length >= 200000) break;
    }
    return Response.ok(jsonEncode(out), headers: _json);
  }

  /// Upload resume / skip ke liye: file (ya adhoori .swiftpart) ka size.
  Future<Response> _stat(Request req) async {
    final base = _resolve(req.url.queryParameters['path'] ?? '');
    if (base == null) return Response.forbidden('Bad path');
    final segs = (req.url.queryParameters['name'] ?? '')
        .split(RegExp(r'[\\/]'))
        .where((x) => x.isNotEmpty && x != '.' && x != '..')
        .map(_cleanSeg)
        .toList();
    if (segs.isEmpty) return Response.badRequest(body: 'Bad name');
    var f = p.joinAll([base, ...segs]);
    if (req.url.queryParameters['part'] == '1') f = '$f.swiftpart';
    final file = File(f);
    final size = await file.exists() ? await file.length() : -1;
    return Response.ok(jsonEncode({'size': size}), headers: _json);
  }

  /// Download: Range support (resume + badi file), seedha stream, memory nahi bharti.
  Future<Response> _get(Request req) async {
    final path = _resolve(req.url.queryParameters['path'] ?? '');
    if (path == null) return Response.forbidden('Bad path');
    final file = File(path);
    if (!await file.exists()) return Response.notFound('File nahi mili');
    final len = await file.length();
    var start = 0;
    var end = len - 1;
    var partial = false;
    final range = req.headers['range'];
    if (range != null && len > 0) {
      final m = RegExp(r'bytes=(\d*)-(\d*)').firstMatch(range);
      if (m != null) {
        final a = m.group(1) ?? '';
        final b = m.group(2) ?? '';
        if (a.isNotEmpty) {
          start = int.parse(a);
          if (b.isNotEmpty) end = min(int.parse(b), len - 1);
        } else if (b.isNotEmpty) {
          start = max(0, len - int.parse(b));
        }
        partial = true;
      }
    }
    if (len > 0 && start >= len) {
      return Response(416, headers: {'content-range': 'bytes */$len'});
    }
    final name = p.basename(path);
    final headers = <String, String>{
      'content-type': 'application/octet-stream',
      'accept-ranges': 'bytes',
      'content-length': '${len == 0 ? 0 : end - start + 1}',
      'content-disposition': "attachment; filename*=UTF-8''${Uri.encodeComponent(name)}",
    };
    if (partial) headers['content-range'] = 'bytes $start-$end/$len';
    final Stream<List<int>> body =
        len == 0 ? Stream<List<int>>.empty() : file.openRead(start, end + 1);
    return Response(partial ? 206 : 200, body: body, headers: headers);
  }

  /// Upload: folder ke andar subfolder bhi, resume (off) ke sath, .swiftpart mein likh kar
  /// complete hone par asli naam.
  Future<Response> _put(Request req) async {
    if (shareAll && !allowUpload) return Response.forbidden('Phone mein likhna band hai');
    final baseDir = _resolve(req.url.queryParameters['path'] ?? '');
    if (baseDir == null) return Response.forbidden('Bad path');
    final off = int.tryParse(req.url.queryParameters['off'] ?? '0') ?? 0;
    final total = int.tryParse(req.url.queryParameters['total'] ?? '-1') ?? -1;
    final segs = (req.url.queryParameters['name'] ?? '')
        .split(RegExp(r'[\\/]'))
        .where((x) => x.isNotEmpty && x != '.' && x != '..')
        .map(_cleanSeg)
        .toList();
    if (segs.isEmpty) return Response.badRequest(body: 'Bad name');
    final folder = Directory(p.joinAll([baseDir, ...segs.sublist(0, segs.length - 1)]));
    await folder.create(recursive: true);
    final fin = p.join(folder.path, segs.last);
    final part = File('$fin.swiftpart');
    final have = await part.exists() ? await part.length() : 0;
    if (off != 0 && off != have) return Response(409, body: '$have');
    final sink = part.openWrite(mode: off == 0 ? FileMode.write : FileMode.append);
    try {
      await sink.addStream(req.read());
      await sink.close();
    } catch (e) {
      try {
        await sink.close();
      } catch (_) {}
      return Response.internalServerError(body: 'Upload beech mein ruk gaya');
    }
    final size = await part.length();
    if (total < 0 || size >= total) {
      final dest = await File(fin).exists() ? _fs.uniquePath(fin) : fin;
      await part.rename(dest);
      received.insert(0, p.basename(dest));
      notifyListeners();
      return Response.ok(jsonEncode({'done': true, 'size': size}), headers: _json);
    }
    return Response.ok(jsonEncode({'done': false, 'size': size}), headers: _json);
  }

  Future<Response> _list() async {
    final out = <Map<String, Object>>[];
    await for (final e in dir.list(followLinks: false)) {
      if (e is File) {
        final name = p.basename(e.path);
        if (name.startsWith('.')) continue;
        out.add({'name': name, 'size': await e.length()});
      }
    }
    out.sort((a, b) =>
        (a['name']! as String).toLowerCase().compareTo((b['name']! as String).toLowerCase()));
    return Response.ok(
      jsonEncode(out),
      headers: {'content-type': 'application/json; charset=utf-8'},
    );
  }

  Future<Response> _download(Request req) async {
    final name = p.basename(req.url.queryParameters['name'] ?? '');
    if (name.isEmpty || name == '.' || name == '..') {
      return Response.badRequest(body: 'Bad name');
    }
    final file = File(p.join(dir.path, name));
    if (!await file.exists()) return Response.notFound('File not found');
    return Response.ok(
      file.openRead(),
      headers: {
        'content-type': 'application/octet-stream',
        'content-length': '${await file.length()}',
        'content-disposition':
            "attachment; filename*=UTF-8''${Uri.encodeComponent(name)}",
      },
    );
  }

  Future<Response> _upload(Request req) async {
    final name = p.basename(req.url.queryParameters['name'] ?? '');
    if (name.isEmpty || name == '.' || name == '..') {
      return Response.badRequest(body: 'Bad name');
    }
    await dir.create(recursive: true);
    final target = File(_fs.uniquePath(p.join(dir.path, name)));
    final sink = target.openWrite();
    try {
      await sink.addStream(req.read());
      await sink.close();
    } catch (e) {
      try {
        await sink.close();
      } catch (_) {}
      if (await target.exists()) await target.delete();
      rethrow;
    }
    received.insert(0, p.basename(target.path));
    notifyListeners();
    return Response.ok('ok');
  }

  Future<String?> _localIp() async {
    final ifaces = await NetworkInterface.list(
      type: InternetAddressType.IPv4,
      includeLoopback: false,
    );
    String? fallback;
    for (final i in ifaces) {
      for (final a in i.addresses) {
        final ip = a.address;
        if (ip.startsWith('169.254')) continue;
        if (ip.startsWith('192.168.')) return ip;
        fallback ??= ip;
      }
    }
    return fallback;
  }
}
