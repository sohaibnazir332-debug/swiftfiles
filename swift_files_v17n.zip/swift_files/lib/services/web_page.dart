/// Ye page dusre device ke browser mein khulta hai (PC ya mobile, koi app install nahi).
/// Phone ke folders dekhna, folder download (bina zip), upload, resume.
const String kWebPage = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SwiftFiles Transfer</title>
<style>
:root{--sky:#4DB6F5;--dark:#1E88E5;--soft:#E3F2FD;--bg:#F4F9FF;--ink:#1B2B3A;--muted:#7A8CA0}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--ink)}
header{background:linear-gradient(135deg,#6CC4F8,#1E88E5);color:#fff;padding:26px 20px 40px;border-radius:0 0 28px 28px}
header h1{margin:0;font-size:24px}
header p{margin:6px 0 0;opacity:.9;font-size:14px}
main{max-width:760px;margin:-24px auto 40px;padding:0 14px}
.card{background:#fff;border-radius:22px;padding:18px;margin-bottom:14px;box-shadow:0 8px 24px rgba(30,136,229,.10)}
h2{margin:0 0 10px;font-size:17px}
input[type=password],input[type=text],input[type=tel]{width:100%;padding:14px 16px;font-size:20px;letter-spacing:6px;text-align:center;border:2px solid var(--soft);border-radius:14px;outline:none;background:var(--bg)}
button,.btn{display:inline-block;padding:12px 16px;border:0;border-radius:14px;background:var(--dark);color:#fff;font-size:15px;font-weight:700;cursor:pointer;text-align:center}
button.full{width:100%;margin-top:12px}
button.ghost{background:var(--soft);color:var(--dark)}
button:disabled{opacity:.5;cursor:default}
.err{color:#EF5350;margin:10px 0 0;min-height:20px;text-align:center}
.crumbs{display:flex;flex-wrap:wrap;gap:4px;align-items:center;margin-bottom:10px;font-size:14px}
.crumbs a{color:var(--dark);font-weight:700;cursor:pointer;padding:4px 8px;border-radius:10px;background:var(--soft)}
.tools{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0 10px}
.row{display:flex;align-items:center;gap:10px;padding:11px 12px;margin-bottom:6px;border-radius:14px;background:var(--bg)}
.row:hover{background:var(--soft)}
.row .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;cursor:pointer}
.row small{color:var(--muted);white-space:nowrap}
.row input{width:20px;height:20px;flex:none}
.muted{color:var(--muted);text-align:center;margin:8px 0}
.bar{height:10px;border-radius:8px;background:var(--soft);margin:8px 0;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:var(--sky);transition:width .2s}
.log{max-height:180px;overflow:auto;font-size:13px;color:var(--muted)}
.log div{padding:2px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.log .bad{color:#EF5350}
[hidden]{display:none!important}
</style>
</head>
<body>
<header>
  <h1>SwiftFiles Transfer</h1>
  <p id="sub">Bina cable ke files bhejein aur lein</p>
</header>
<main>
  <section class="card" id="lock">
    <h2>PIN daalein</h2>
    <input id="pin" type="tel" inputmode="numeric" maxlength="4" placeholder="----" autocomplete="off">
    <button class="full" onclick="unlock()">Connect</button>
    <div class="err" id="err"></div>
  </section>

  <div id="app" hidden>
    <section class="card">
      <h2 id="where">Files</h2>
      <div class="crumbs" id="crumbs"></div>
      <div class="tools">
        <button class="ghost" id="selAll">Sab chunein</button>
        <button id="dl" disabled>⬇ Download</button>
        <button class="ghost" id="upF">⬆ Files bhejein</button>
        <button class="ghost" id="upD">⬆ Folder bhejein</button>
      </div>
      <input id="pickF" type="file" multiple hidden>
      <input id="pickD" type="file" webkitdirectory multiple hidden>
      <div id="list"></div>
    </section>
    <section class="card" id="prog" hidden>
      <h2 id="ptitle">Transfer</h2>
      <div id="ptext" class="muted" style="text-align:left;margin:0"></div>
      <div class="bar"><i id="pbar"></i></div>
      <div id="pspeed" class="muted" style="text-align:left;margin:0"></div>
      <div class="log" id="log"></div>
    </section>
    <section class="card muted" style="text-align:left;font-size:13px" id="tip"></section>
  </div>
</main>

<script>
let pin = sessionStorage.getItem('pin') || '';
let INFO = {all:false, up:true};
let cwd = '';
let ITEMS = [];
const SEL = new Set();
const $ = id => document.getElementById(id);
const hdr = () => ({'x-pin': pin});
const q = s => encodeURIComponent(s);

function fmt(n){
  if (n < 1024) return n + ' B';
  const u = ['KB','MB','GB','TB']; let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < 3);
  return n.toFixed(n >= 10 ? 0 : 1) + ' ' + u[i];
}
function fmtT(s){
  s = Math.max(0, Math.round(s));
  if (s < 60) return s + ' sec';
  if (s < 3600) return Math.floor(s/60) + ' min ' + (s%60) + ' sec';
  return Math.floor(s/3600) + ' ghanta ' + Math.floor(s%3600/60) + ' min';
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const join = (a, b) => a ? a + '/' + b : b;

async function api(path){
  const r = await fetch(path, {headers: hdr()});
  if (!r.ok) { const e = new Error(await r.text() || r.status); e.status = r.status; throw e; }
  return r.json();
}

async function unlock(){
  pin = $('pin').value.trim();
  try {
    INFO = await api('/api/info');
    sessionStorage.setItem('pin', pin);
    $('lock').hidden = true; $('app').hidden = false;
    $('upF').hidden = $('upD').hidden = !INFO.up;
    $('tip').textContent = INFO.all
      ? 'Tip: bade folder ke liye PC par Chrome ya Edge use karein. Download dabane par PC ka folder chunein, files seedhi usme likhi jayengi (zip nahi banta). Beech mein ruk jaye to dobara Download dabayein, wahin se chalega.'
      : 'Abhi sirf "SwiftFiles" transfer folder dikh raha hai. Poora phone dekhne ke liye phone ke app mein "Poori storage dikhayein" ON karein.';
    await go('');
  } catch (e) {
    $('err').textContent = e.status === 403 ? 'PIN galat hai' : 'Server nahi mila. Dono devices ek hi Wi-Fi par hon.';
  }
}

async function go(path){
  try {
    const r = await api('/api/ls?path=' + q(path));
    cwd = path; ITEMS = r.items; SEL.clear(); draw();
  } catch (e) {
    toastErr(e.status === 403 ? 'Permission nahi hai ya folder band hai' : 'Folder nahi khula: ' + e.message);
  }
}
function toastErr(m){ log(m, true); $('prog').hidden = false; }

function draw(){
  const cr = $('crumbs'); cr.textContent = '';
  const mk = (label, p) => { const a = document.createElement('a'); a.textContent = label; a.onclick = () => go(p); cr.appendChild(a); };
  mk(INFO.all ? 'Phone' : 'Transfer', '');
  let acc = '';
  cwd.split('/').filter(Boolean).forEach(s => { acc = join(acc, s); const sep = document.createElement('span'); sep.textContent = '›'; cr.appendChild(sep); mk(s, acc); });

  const box = $('list'); box.textContent = '';
  if (!ITEMS.length) { const p = document.createElement('p'); p.className = 'muted'; p.textContent = 'Ye folder khali hai.'; box.appendChild(p); }
  const sorted = [...ITEMS].sort((a, b) => (b.d - a.d) || a.n.localeCompare(b.n, undefined, {numeric: true}));
  sorted.forEach(it => {
    const row = document.createElement('div'); row.className = 'row';
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = SEL.has(it.n);
    cb.onchange = () => { cb.checked ? SEL.add(it.n) : SEL.delete(it.n); upd(); };
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = (it.d ? '📁 ' : '📄 ') + it.n;
    nm.onclick = () => it.d ? go(join(cwd, it.n)) : download([{path: join(cwd, it.n), name: it.n, size: it.s}]);
    const sz = document.createElement('small'); sz.textContent = it.d ? '' : fmt(it.s);
    row.append(cb, nm, sz); box.appendChild(row);
  });
  upd();
}
function upd(){
  $('dl').disabled = !SEL.size;
  $('dl').textContent = SEL.size ? '⬇ Download (' + SEL.size + ')' : '⬇ Download';
  $('selAll').textContent = SEL.size === ITEMS.length && ITEMS.length ? 'Kuch na chunein' : 'Sab chunein';
}
$('selAll').onclick = () => {
  if (SEL.size === ITEMS.length) SEL.clear(); else ITEMS.forEach(i => SEL.add(i.n));
  draw();
};
$('dl').onclick = async () => {
  const jobs = [];
  for (const it of ITEMS.filter(i => SEL.has(i.n))) {
    if (!it.d) { jobs.push({path: join(cwd, it.n), name: it.n, size: it.s}); continue; }
    try {
      const t = await api('/api/tree?path=' + q(join(cwd, it.n)));
      t.forEach(([rel, size]) => jobs.push({path: join(join(cwd, it.n), rel), name: it.n + '/' + rel, size}));
    } catch (e) { log('Folder padh nahi paya: ' + it.n, true); }
  }
  if (!jobs.length) { log('Download ke liye koi file nahi mili', true); $('prog').hidden = false; return; }
  download(jobs);
};

/* ---------- progress ---------- */
const P = {total: 0, done: 0, files: 0, filesDone: 0, t0: 0, smp: [], on: false};
function pStart(title, jobs){
  P.total = jobs.reduce((a, j) => a + j.size, 0); P.done = 0; P.files = jobs.length; P.filesDone = 0;
  P.t0 = performance.now(); P.smp = []; P.on = true;
  $('prog').hidden = false; $('ptitle').textContent = title; $('log').textContent = '';
  pDraw();
}
function pDraw(){
  const now = performance.now();
  P.smp.push([now, P.done]); while (P.smp.length > 1 && now - P.smp[0][0] > 5000) P.smp.shift();
  const a = P.smp[0], sp = (P.done - a[1]) / Math.max((now - a[0]) / 1000, .5);
  $('ptext').textContent = P.filesDone + ' / ' + P.files + ' files · ' + fmt(P.done) + ' / ' + fmt(P.total);
  $('pbar').style.width = (P.total ? P.done / P.total * 100 : 100) + '%';
  $('pspeed').textContent = P.on ? (sp > 1024 ? fmt(sp) + '/s · ' + fmtT((P.total - P.done) / sp) + ' baaki' : '…') : '';
}
function log(m, bad){ const d = document.createElement('div'); if (bad) d.className = 'bad'; d.textContent = m; $('log').prepend(d); }
setInterval(() => { if (P.on) pDraw(); }, 500);
let wl = null;
async function awake(on){ try { if (on && navigator.wakeLock) wl = await navigator.wakeLock.request('screen'); else if (wl) { await wl.release(); wl = null; } } catch (e) {} }

async function pool(jobs, n, fn){
  let i = 0;
  const w = async () => { while (i < jobs.length) { const j = jobs[i++]; await fn(j); } };
  await Promise.all(Array.from({length: n}, w));
}

/* ---------- download ---------- */
async function download(jobs){
  if (!jobs.length) return;
  if (window.showDirectoryPicker) {
    let root;
    try { root = await showDirectoryPicker({mode: 'readwrite'}); } catch (e) { return; }
    pStart('Download ho raha hai → ' + root.name, jobs); awake(true);
    await pool(jobs, 3, j => saveToFolder(root, j));
    P.on = false; pDraw(); awake(false);
    log('Download complete ✓ (' + P.filesDone + ' files)');
  } else {
    pStart('Download ho raha hai (browser ke Downloads mein)', jobs);
    for (const j of jobs) {
      const a = document.createElement('a');
      a.href = '/get?path=' + q(j.path) + '&pin=' + q(pin);
      a.download = j.name.replace(/\//g, '_');
      document.body.appendChild(a); a.click(); a.remove();
      P.done += j.size; P.filesDone++; log('✓ ' + j.name);
      await sleep(700);
    }
    P.on = false; pDraw();
  }
}
async function dirFor(root, parts){
  let d = root;
  for (const p of parts) d = await d.getDirectoryHandle(p, {create: true});
  return d;
}
async function saveToFolder(root, j){
  const parts = j.name.split('/'); const fname = parts.pop();
  const dir = await dirFor(root, parts);
  const fh = await dir.getFileHandle(fname, {create: true});
  for (let attempt = 0; attempt < 6; attempt++) {
    let have = (await fh.getFile()).size;
    if (have === j.size) { P.done += j.size; P.filesDone++; log('⏭ ' + j.name + ' (pehle se hai)'); return; }
    if (have > j.size) have = 0;
    let base = have, got = 0, w = null;
    try {
      const headers = Object.assign({}, hdr());
      if (have > 0) headers['range'] = 'bytes=' + have + '-';
      const r = await fetch('/get?path=' + q(j.path), {headers});
      if (!(r.ok || r.status === 206)) throw new Error('HTTP ' + r.status);
      if (have > 0 && r.status !== 206) base = 0;
      w = await fh.createWritable({keepExistingData: base > 0});
      if (base > 0) await w.seek(base);
      const rd = r.body.getReader();
      for (;;) {
        const {done, value} = await rd.read();
        if (done) break;
        await w.write(value); got += value.length; P.done += value.length;
      }
      await w.close(); w = null;
      P.filesDone++; log('✓ ' + j.name + ' (' + fmt(j.size) + ')'); return;
    } catch (e) {
      try { if (w) await w.close(); } catch (x) {}
      P.done -= got;
      if (attempt === 5) { log('✕ ' + j.name + ' — ' + e.message, true); P.filesDone++; return; }
      await sleep(1500 * (attempt + 1));
    }
  }
}

/* ---------- upload ---------- */
$('upF').onclick = () => $('pickF').click();
$('upD').onclick = () => $('pickD').click();
$('pickF').onchange = e => { upload([...e.target.files]); e.target.value = ''; };
$('pickD').onchange = e => { upload([...e.target.files]); e.target.value = ''; };

async function upload(files){
  if (!files.length) return;
  const jobs = files.map(f => ({file: f, name: f.webkitRelativePath || f.name, size: f.size}));
  pStart('Phone mein bhej raha hai → ' + (cwd || '/'), jobs); awake(true);
  await pool(jobs, 2, upOne);
  P.on = false; pDraw(); awake(false);
  log('Upload complete ✓');
  go(cwd);
}
async function upOne(j){
  const dest = 'path=' + q(cwd) + '&name=' + q(j.name);
  for (let attempt = 0; attempt < 6; attempt++) {
    let off = 0;
    try {
      const fin = await api('/api/stat?' + dest);
      if (fin.size === j.size) { P.done += j.size; P.filesDone++; log('⏭ ' + j.name + ' (pehle se hai)'); return; }
      const part = await api('/api/stat?' + dest + '&part=1');
      off = part.size > 0 && part.size <= j.size ? part.size : 0;
    } catch (e) { await sleep(1000); continue; }
    let sent = off;
    try {
      await new Promise((res, rej) => {
        const x = new XMLHttpRequest();
        x.open('PUT', '/put?' + dest + '&off=' + off + '&total=' + j.size);
        x.setRequestHeader('x-pin', pin);
        let last = 0;
        x.upload.onprogress = e => { const d = e.loaded - last; last = e.loaded; sent += d; P.done += d; };
        x.onload = () => x.status === 200 ? res() : rej(new Error(x.responseText || ('HTTP ' + x.status)));
        x.onerror = () => rej(new Error('connection toot gaya'));
        x.send(j.file.slice(off));
        j._x = x; j._last = () => last;
      });
      P.filesDone++; log('✓ ' + j.name + ' (' + fmt(j.size) + ')'); return;
    } catch (e) {
      P.done -= (sent - off);
      if (attempt === 5) { log('✕ ' + j.name + ' — ' + e.message, true); P.filesDone++; return; }
      await sleep(1500 * (attempt + 1));
    }
  }
}

$('pin').addEventListener('keydown', e => { if (e.key === 'Enter') unlock(); });
if (pin) { $('pin').value = pin; unlock(); }
</script>
</body>
</html>
''';
