import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../core/format.dart';
import '../core/theme.dart';
import '../providers/browser_provider.dart';
import '../services/nearby_service.dart';
import 'qr_scan_screen.dart';

/// ShareIt jaisa: aas paas ke SwiftFiles devices dikhte hain, tap karo, files chali jati hain.
/// [paths] khali ho to ye screen sirf "receive" ke liye khuli hai.
class NearbyScreen extends ConsumerStatefulWidget {
  const NearbyScreen({super.key, this.paths = const []});
  final List<String> paths;

  @override
  ConsumerState<NearbyScreen> createState() => _NearbyScreenState();
}

class _NearbyScreenState extends ConsumerState<NearbyScreen> {
  late final NearbyService _svc;
  bool _dialogOpen = false;

  @override
  void initState() {
    super.initState();
    _svc = ref.read(nearbyProvider);
    WidgetsBinding.instance.addPostFrameCallback((_) => _svc.start());
  }

  @override
  void dispose() {
    final svc = _svc;
    // Widget tree lock ke dauran notify na ho, isliye agle microtask mein
    Future<void>.microtask(() {
      svc.cancel();
      svc.clearJob();
      svc.stop();
    });
    super.dispose();
  }

  void _maybeShowOffer() {
    final t = ref.read(transferProvider);
    final o = t.pendingOffer;
    if (o == null || _dialogOpen || !mounted) return;
    _dialogOpen = true;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text('${o.name} files bhejna chahta hai'),
        content: Text('${o.files} files · ${formatSize(o.bytes)}'),
        actions: [
          TextButton(
            onPressed: () {
              t.answerOffer(false);
              Navigator.pop(ctx);
            },
            child: const Text('Mana karein'),
          ),
          FilledButton(
            onPressed: () {
              t.answerOffer(true);
              Navigator.pop(ctx);
            },
            child: const Text('Accept'),
          ),
        ],
      ),
    ).whenComplete(() => _dialogOpen = false);
  }

  @override
  Widget build(BuildContext context) {
    final svc = ref.watch(nearbyProvider);
    final t = ref.watch(transferProvider);
    if (t.pendingOffer != null && !_dialogOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowOffer());
    }
    final peers = svc.peerList;
    final job = svc.job;
    final sending = widget.paths.isNotEmpty;

    return Scaffold(
      body: Column(
        children: [
          _header(context),
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 640),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 18, 16, 32),
                  children: [
                    _card(
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Aap ka naam: ${svc.name}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            sending
                                ? '${widget.paths.length} item bhejne hain. Neeche device par tap karein.'
                                : 'Dusre device par bhi SwiftFiles kholein → Aas paas. Phir wahan se file chun kar is device ko bhejein. Ye screen khuli rakhein.',
                            style: const TextStyle(
                              color: AppColors.muted,
                              height: 1.35,
                            ),
                          ),
                          if (svc.error != null) ...[
                            const SizedBox(height: 8),
                            Text(
                              svc.error!,
                              style: const TextStyle(color: AppColors.danger),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    _qrCard(svc),
                    const SizedBox(height: 14),
                    const Padding(
                      padding: EdgeInsets.only(left: 6, bottom: 8),
                      child: Text(
                        'Aas paas ke devices',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    if (peers.isEmpty)
                      _card(
                        const Row(
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2.4),
                            ),
                            SizedBox(width: 14),
                            Expanded(
                              child: Text(
                                'Dhoond raha hai… dono devices ek hi Wi-Fi (ya hotspot) par hon aur dusre par bhi ye screen khuli ho.',
                                style: TextStyle(
                                  color: AppColors.muted,
                                  height: 1.35,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    for (final peer in peers) ...[
                      _peerTile(svc, peer, sending),
                      const SizedBox(height: 10),
                    ],
                    if (job != null) ...[
                      const SizedBox(height: 6),
                      _jobCard(svc, job),
                    ],
                    if (t.received.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      _card(
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Mili hui files',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                            const SizedBox(height: 6),
                            for (final f in t.received.take(8))
                              Text('• $f', maxLines: 1, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 6),
                            Text(
                              'Folder: ${t.dir.path}',
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 12.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _scan(NearbyService svc) async {
    final raw = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const QrScanScreen()),
    );
    if (raw == null || !mounted) return;
    final ok = svc.addFromQr(raw);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Device mil gaya. Neeche us par tap karein.'
              : 'Ye SwiftFiles ka QR nahi hai.',
        ),
      ),
    );
  }

  /// Apna QR (dusra device scan kare) + scan button (sirf Android par camera).
  Widget _qrCard(NearbyService svc) {
    final addr = svc.selfAddr;
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Device nahi dikh raha? QR se jodein',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 4),
          const Text(
            'Ek device ka QR doosre se scan karein (laptop par camera nahi ho to phone ka QR laptop par dikhta hai; phone se laptop wala scan karein).',
            style: TextStyle(color: AppColors.muted, height: 1.35, fontSize: 13),
          ),
          const SizedBox(height: 12),
          if (addr != null)
            Center(
              child: QrImageView(
                data: svc.selfQr,
                size: 170,
                backgroundColor: Colors.white,
              ),
            ),
          if (addr != null)
            Center(
              child: Text(
                addr,
                style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
              ),
            ),
          if (Platform.isAndroid) ...[
            const SizedBox(height: 10),
            Center(
              child: FilledButton.icon(
                onPressed: () => _scan(svc),
                icon: const Icon(Icons.qr_code_scanner_rounded),
                label: const Text('QR scan karein'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        8,
        MediaQuery.paddingOf(context).top + 8,
        16,
        22,
      ),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF6CC4F8), AppColors.skyDark],
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          ),
          const SizedBox(width: 4),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Aas paas ke devices',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  'App se app, seedhi aur tez',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _card(Widget child) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [
            BoxShadow(
              color: Color(0x141E88E5),
              blurRadius: 18,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: child,
      );

  Widget _peerTile(NearbyService svc, NearbyPeer peer, bool sending) {
    final desktop = peer.os == 'windows' || peer.os == 'linux' || peer.os == 'macos';
    final busy = svc.job != null && svc.job!.active;
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: busy
          ? null
          : () {
              if (!sending) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Bhejne ke liye pehle file/folder chunein, phir "Aas paas" dabayein.',
                    ),
                  ),
                );
                return;
              }
              svc.send(peer, widget.paths);
            },
      child: _card(
        Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.skySoft,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                desktop ? Icons.computer_rounded : Icons.smartphone_rounded,
                color: AppColors.skyDark,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    peer.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    peer.ip,
                    style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
                  ),
                ],
              ),
            ),
            if (sending)
              const Icon(Icons.send_rounded, color: AppColors.skyDark),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(NearbyService svc, SendJob j) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Pakka hata dein?'),
        content: Text(
          '${j.files} files (${formatSize(j.total)}) is device se hamesha ke liye delete hongi. '
          'Ye sab dusre device par check ho kar sahi mil chuki hain. Ye wapas nahi aayengi.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Nahi'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Haan, hata do'),
          ),
        ],
      ),
    );
    if (ok == true) await svc.deleteSent();
  }

  Widget _jobCard(NearbyService svc, SendJob j) {
    final frac = j.total > 0 ? (j.done / j.total).clamp(0.0, 1.0) : 0.0;
    String status;
    if (j.waiting) {
      status = '${j.peerName} ke Accept karne ka intezar…';
    } else if (j.declined) {
      status = '${j.peerName} ne mana kar diya';
    } else if (j.error != null) {
      status = j.error!;
    } else if (j.verifying) {
      status = 'Check ho raha hai… ${j.verified + j.mismatch}/${j.files}';
    } else if (j.deleted) {
      status = 'Ho gaya ✓ ${j.deletedCount} files phone se hata di gayi';
    } else if (j.finished && j.mismatch > 0) {
      status = '⚠ ${j.mismatch} files sahi nahi pahunchi. Dobara bhejein (sirf wahi jayengi)';
    } else if (j.finished) {
      status = 'Ho gaya ✓ ${j.files} files sahi salamat pahunch gayi (check ho chuki)';
    } else {
      status = '${j.peerName} ko bhej raha hai · ${j.filesDone}/${j.files} files';
    }
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(status, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          LinearProgressIndicator(
            value: j.waiting ? null : frac,
            minHeight: 8,
            borderRadius: BorderRadius.circular(8),
          ),
          const SizedBox(height: 8),
          Text(
            '${formatSize(j.done)} / ${formatSize(j.total)}'
            '${j.speed > 1024 ? ' · ${formatSize(j.speed.round())}/s' : ''}',
            style: const TextStyle(color: AppColors.muted, fontSize: 13),
          ),
          if (j.current.isNotEmpty && j.active)
            Text(
              j.current,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
            ),
          const SizedBox(height: 8),
          if (j.active || j.verifying)
            OutlinedButton(onPressed: svc.cancel, child: const Text('Roken'))
          else ...[
            if (j.allVerified && !j.deleted)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                  onPressed: () => _confirmDelete(svc, j),
                  icon: const Icon(Icons.delete_sweep_rounded),
                  label: const Text('Bheji hui files is device se hata dein'),
                ),
              ),
            OutlinedButton(onPressed: svc.clearJob, child: const Text('Theek hai')),
          ],
        ],
      ),
    );
  }
}
