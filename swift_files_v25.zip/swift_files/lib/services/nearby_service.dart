import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

import 'transfer_service.dart';

/// Aas paas ka koi dusra SwiftFiles device (ShareIt jaisa).
class NearbyPeer {
  NearbyPeer({
    required this.id,
    required this.name,
    required this.ip,
    required this.port,
    required this.os,
    required this.seen,
  });

  final String id;
  final String name;
  final String ip;
  final int port;
  final String os;
  DateTime seen;
}

/// Ek bhejne ka kaam (progress yahan rehta hai).
class SendJob {
  SendJob(this.peerName);
  final String peerName;
  int files = 0;
  int filesDone = 0;
  int total = 0;
  int done = 0;
  double speed = 0;
  String current = '';
  String? error;
  bool waiting = false; // samne wala Accept kar raha hai
  bool declined = false;
  bool finished = false;
  // Verify + delete
  bool verifying = false;
  int verified = 0; // receiver par sahi size mein mili files
  int mismatch = 0; // jo nahi mili / size alag
  bool deleted = false;
  int deletedCount = 0;
  List<String> sentPaths = [];
  List<String> roots = [];

  bool get allVerified => finished && !verifying && mismatch == 0 && verified == files && files > 0;

  bool get active => !finished && !declined && error == null;
}

class _Item {
  _Item(this.path, this.rel, this.size);
  final String path;
  final String rel;
  final int size;
}

/// App se app transfer: dono devices par SwiftFiles, ek hi Wi-Fi / hotspot.
///  - UDP broadcast se aas paas ke devices dikhte hain
///  - bhejne wala offer deta hai, samne wala Accept karta hai
///  - files seedhi HTTP se (resume ke saath) receive folder mein jati hain
class NearbyService extends ChangeNotifier {
  NearbyService(this._t) {
    final rnd = Random.secure();
    id = List.generate(10, (_) => rnd.nextInt(36).toRadixString(36)).join();
    final tag = id.substring(0, 3);
    name = Platform.isAndroid ? 'Phone-$tag' : '${Platform.localHostname}-$tag';
  }

  static const int discoveryPort = 45454;

  final TransferService _t;
  late final String id;
  late final String name;

  RawDatagramSocket? _sock;
  Timer? _beat;
  Timer? _prune;
  bool _startedServer = false;
  bool _cancel = false;
  int _lastNotify = 0;
  int _lastBytes = 0;
  int _lastMs = 0;

  final Map<String, NearbyPeer> peers = {};
  SendJob? job;
  String? error;

  bool get active => _sock != null;

  List<NearbyPeer> get peerList {
    final l = peers.values.toList();
    l.sort((a, b) => a.name.compareTo(b.name));
    return l;
  }

  // ---------------------------------------------------------------- discovery

  Future<void> start() async {
    if (active) return;
    error = null;
    if (!_t.running) {
      await _t.start();
      _startedServer = true;
    }
    if (!_t.running) {
      error = 'Server start nahi hua. Wi-Fi check karein.';
      notifyListeners();
      return;
    }
    _t.nearbyOn = true;
    try {
      RawDatagramSocket s;
      try {
        s = await RawDatagramSocket.bind(
          InternetAddress.anyIPv4,
          discoveryPort,
          reuseAddress: true,
          reusePort: !Platform.isWindows,
        );
      } catch (_) {
        s = await RawDatagramSocket.bind(
          InternetAddress.anyIPv4,
          discoveryPort,
          reuseAddress: true,
        );
      }
      s.broadcastEnabled = true;
      s.listen(_onEvent);
      _sock = s;
    } catch (e) {
      error = 'Aas paas ke devices dhoondne ki permission/port nahi mila: $e';
      _t.nearbyOn = false;
      notifyListeners();
      return;
    }
    _beat = Timer.periodic(const Duration(seconds: 2), (_) => _announce());
    _prune = Timer.periodic(const Duration(seconds: 3), (_) => _pruneOld());
    _announce();
    notifyListeners();
  }

  Future<void> stop() async {
    _beat?.cancel();
    _prune?.cancel();
    _beat = null;
    _prune = null;
    _sock?.close();
    _sock = null;
    _t.nearbyOn = false;
    peers.clear();
    if (_startedServer) {
      _startedServer = false;
      await _t.stop();
    }
    notifyListeners();
  }

  Future<List<InternetAddress>> _targets() async {
    final out = <InternetAddress>[InternetAddress('255.255.255.255')];
    try {
      final ifaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final i in ifaces) {
        for (final a in i.addresses) {
          final parts = a.address.split('.');
          if (parts.length == 4) {
            out.add(InternetAddress('${parts[0]}.${parts[1]}.${parts[2]}.255'));
          }
        }
      }
    } catch (_) {}
    return out;
  }

  Future<void> _announce() async {
    final s = _sock;
    final port = _t.port;
    if (s == null || port == null) return;
    final data = utf8.encode(jsonEncode({
      'app': 'swiftfiles',
      'id': id,
      'name': name,
      'port': port,
      'os': Platform.operatingSystem,
    }));
    for (final t in await _targets()) {
      try {
        s.send(data, t, discoveryPort);
      } catch (_) {}
    }
  }

  void _onEvent(RawSocketEvent e) {
    if (e != RawSocketEvent.read) return;
    final s = _sock;
    if (s == null) return;
    Datagram? d = s.receive();
    var changed = false;
    while (d != null) {
      try {
        final m = jsonDecode(utf8.decode(d.data)) as Map<String, dynamic>;
        final pid = (m['id'] ?? '').toString();
        if (m['app'] == 'swiftfiles' && pid.isNotEmpty && pid != id) {
          final port = (m['port'] as num).toInt();
          final isNew = !peers.containsKey(pid);
          peers[pid] = NearbyPeer(
            id: pid,
            name: (m['name'] ?? 'Device').toString(),
            ip: d.address.address,
            port: port,
            os: (m['os'] ?? '').toString(),
            seen: DateTime.now(),
          );
          if (isNew) changed = true;
        }
      } catch (_) {}
      d = s.receive();
    }
    if (changed) notifyListeners();
  }

  void _pruneOld() {
    final cut = DateTime.now().subtract(const Duration(seconds: 9));
    final before = peers.length;
    peers.removeWhere((_, v) => v.seen.isBefore(cut));
    if (peers.length != before) notifyListeners();
  }

  // ------------------------------------------------------------------ sending

  void cancel() {
    _cancel = true;
  }

  void clearJob() {
    job = null;
    notifyListeners();
  }

  Future<void> send(NearbyPeer peer, List<String> paths) async {
    if (job != null && job!.active) return;
    final j = SendJob(peer.name);
    job = j;
    _cancel = false;
    notifyListeners();
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final items = await _expand(paths);
      j.files = items.length;
      j.total = items.fold<int>(0, (a, b) => a + b.size);
      if (items.isEmpty) {
        j.error = 'Bhejne ke liye koi file nahi mili';
        return;
      }
      j.waiting = true;
      notifyListeners();
      final token = await _offer(client, peer, j);
      j.waiting = false;
      if (token == null) {
        j.declined = true;
        return;
      }
      j.sentPaths = items.map((e) => e.path).toList();
      j.roots = List<String>.from(paths);
      _lastBytes = 0;
      _lastMs = DateTime.now().millisecondsSinceEpoch;
      for (final it in items) {
        if (_cancel) break;
        j.current = it.rel;
        notifyListeners();
        await _sendOne(client, peer, token, it, j);
        j.filesDone++;
      }
      if (_cancel) {
        j.error = 'Beech mein roka gaya';
      } else {
        j.finished = true;
        j.speed = 0;
        j.verifying = true;
        j.current = '';
        notifyListeners();
        await _verify(client, peer, token, items, j);
        j.verifying = false;
      }
    } catch (e) {
      j.waiting = false;
      j.error = 'Bhejna nahi ho saka. Dono devices ek hi Wi-Fi par hon aur samne wali app khuli ho. ($e)';
    } finally {
      client.close(force: true);
      notifyListeners();
    }
  }

  /// Bhejne ke baad samne wale device se har file ka size dobara poochh kar milata hai.
  Future<void> _verify(
    HttpClient c,
    NearbyPeer peer,
    String token,
    List<_Item> items,
    SendJob j,
  ) async {
    final base = 'http://${peer.ip}:${peer.port}';
    for (final it in items) {
      var ok = false;
      for (var a = 0; a < 3 && !ok; a++) {
        try {
          final enc = Uri.encodeQueryComponent(it.rel);
          final r = await _getJson(c, '$base/nearby/stat?name=$enc', token);
          ok = (r['size'] as num).toInt() == it.size;
          break;
        } catch (_) {
          await Future<void>.delayed(const Duration(seconds: 1));
        }
      }
      if (ok) {
        j.verified++;
      } else {
        j.mismatch++;
      }
      if (_lastNotify + 250 < DateTime.now().millisecondsSinceEpoch) {
        _lastNotify = DateTime.now().millisecondsSinceEpoch;
        notifyListeners();
      }
    }
  }

  /// Sirf tab chalta hai jab har file samne wale par sahi size mein verify ho chuki ho.
  /// Is device se bheji hui files delete karta hai, phir khali folders hata deta hai.
  Future<void> deleteSent() async {
    final j = job;
    if (j == null || !j.allVerified || j.deleted) return;
    var n = 0;
    for (final path in j.sentPaths) {
      try {
        final f = File(path);
        if (await f.exists()) {
          await f.delete();
          n++;
        }
      } catch (_) {}
    }
    for (final r in j.roots) {
      try {
        if (FileSystemEntity.typeSync(r) == FileSystemEntityType.directory) {
          await _pruneEmpty(Directory(r));
        }
      } catch (_) {}
    }
    j.deleted = true;
    j.deletedCount = n;
    notifyListeners();
  }

  /// Khali folders hatata hai (andar file ho to folder chhod deta hai).
  Future<bool> _pruneEmpty(Directory d) async {
    var empty = true;
    try {
      await for (final e in d.list(followLinks: false)) {
        if (e is Directory) {
          if (!await _pruneEmpty(e)) empty = false;
        } else {
          empty = false;
        }
      }
      if (empty) await d.delete();
    } catch (_) {
      return false;
    }
    return empty;
  }

  /// Apna address (QR ke liye): ip:port. Server na chal raha ho to null.
  String? get selfAddr {
    final u = _t.url;
    if (u == null) return null;
    final uri = Uri.tryParse(u);
    if (uri == null || uri.host.isEmpty) return null;
    return '${uri.host}:${uri.port}';
  }

  String get selfQr => 'swiftfiles://${selfAddr ?? ''}|$name|${Platform.isAndroid ? 'android' : 'windows'}';

  /// QR scan se mile address se device jodna (jab auto-discovery na chale).
  bool addFromQr(String raw) {
    if (!raw.startsWith('swiftfiles://')) return false;
    final parts = raw.substring('swiftfiles://'.length).split('|');
    if (parts.isEmpty) return false;
    final hp = parts[0].split(':');
    if (hp.length != 2) return false;
    final port = int.tryParse(hp[1]);
    if (port == null || hp[0].isEmpty) return false;
    final nm = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : hp[0];
    final os = parts.length > 2 ? parts[2] : 'android';
    final id = 'qr-${hp[0]}:$port';
    peers[id] = NearbyPeer(
      id: id,
      name: nm,
      ip: hp[0],
      port: port,
      os: os,
      seen: DateTime.now().add(const Duration(hours: 8)),
    );
    notifyListeners();
    return true;
  }

  Future<String?> _offer(HttpClient c, NearbyPeer peer, SendJob j) async {
    final req = await c.postUrl(
      Uri.parse('http://${peer.ip}:${peer.port}/nearby/offer'),
    );
    req.headers.contentType = ContentType.json;
    req.write(jsonEncode({'name': name, 'files': j.files, 'bytes': j.total}));
    final res = await req.close().timeout(const Duration(seconds: 75));
    final body = await res.transform(utf8.decoder).join();
    if (res.statusCode == 403) {
      throw const HttpException('Samne wale device par "Aas paas" screen khuli nahi hai');
    }
    if (res.statusCode != 200) return null;
    final m = jsonDecode(body) as Map<String, dynamic>;
    return m['ok'] == true ? m['token'] as String : null;
  }

  Future<Map<String, dynamic>> _getJson(
    HttpClient c,
    String url,
    String token,
  ) async {
    final req = await c.getUrl(Uri.parse(url));
    req.headers.set('x-pin', token);
    final res = await req.close();
    final body = await res.transform(utf8.decoder).join();
    if (res.statusCode != 200) {
      throw HttpException('HTTP ${res.statusCode}');
    }
    return jsonDecode(body) as Map<String, dynamic>;
  }

  Future<void> _sendOne(
    HttpClient c,
    NearbyPeer peer,
    String token,
    _Item it,
    SendJob j,
  ) async {
    final base = 'http://${peer.ip}:${peer.port}';
    final enc = Uri.encodeQueryComponent(it.rel);
    final startDone = j.done;
    for (var attempt = 0; attempt < 5; attempt++) {
      if (_cancel) return;
      j.done = startDone;
      try {
        final fin = await _getJson(c, '$base/nearby/stat?name=$enc', token);
        if ((fin['size'] as num).toInt() == it.size) {
          j.done = startDone + it.size;
          return;
        }
        final part = await _getJson(c, '$base/nearby/stat?part=1&name=$enc', token);
        var off = (part['size'] as num).toInt();
        if (off < 0 || off > it.size) off = 0;
        var sent = 0;
        final req = await c.putUrl(
          Uri.parse('$base/nearby/put?name=$enc&off=$off&total=${it.size}'),
        );
        req.headers.set('x-pin', token);
        req.contentLength = it.size - off;
        await req.addStream(
          File(it.path).openRead(off).map((chunk) {
            sent += chunk.length;
            j.done = startDone + off + sent;
            _progress(j);
            return chunk;
          }),
        );
        final res = await req.close();
        await res.drain<void>();
        if (res.statusCode == 200) {
          j.done = startDone + it.size;
          return;
        }
        throw HttpException('HTTP ${res.statusCode}');
      } catch (_) {
        if (attempt == 4 || _cancel) rethrow;
        await Future<void>.delayed(Duration(seconds: 2 * (attempt + 1)));
      }
    }
  }

  void _progress(SendJob j) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastNotify < 250) return;
    _lastNotify = now;
    final dt = now - _lastMs;
    if (dt >= 1000) {
      j.speed = (j.done - _lastBytes) * 1000 / dt;
      _lastBytes = j.done;
      _lastMs = now;
    }
    notifyListeners();
  }

  Future<List<_Item>> _expand(List<String> paths) async {
    final out = <_Item>[];
    for (final path in paths) {
      final type = FileSystemEntity.typeSync(path);
      if (type == FileSystemEntityType.directory) {
        final top = p.basename(path);
        final stream = Directory(path)
            .list(recursive: true, followLinks: false)
            .handleError((_) {});
        await for (final e in stream) {
          if (e is! File) continue;
          final rel = p.relative(e.path, from: path).replaceAll('\\', '/');
          if (rel.split('/').any((x) => x.startsWith('.'))) continue;
          try {
            out.add(_Item(e.path, '$top/$rel', await e.length()));
          } catch (_) {}
        }
      } else if (type == FileSystemEntityType.file) {
        try {
          out.add(_Item(path, p.basename(path), await File(path).length()));
        } catch (_) {}
      }
    }
    return out;
  }

  @override
  void dispose() {
    _beat?.cancel();
    _prune?.cancel();
    _sock?.close();
    super.dispose();
  }
}
