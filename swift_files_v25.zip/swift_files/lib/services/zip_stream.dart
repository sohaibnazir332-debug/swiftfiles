import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

/// Ek zip entry: [rel] zip ke andar ka path ('/' wala), [file] asli file.
class ZipEntryInfo {
  ZipEntryInfo(this.rel, this.file);
  final String rel;
  final File file;
}

final List<int> _crcTable = () {
  final t = List<int>.filled(256, 0);
  for (var n = 0; n < 256; n++) {
    var c = n;
    for (var k = 0; k < 8; k++) {
      c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1);
    }
    t[n] = c;
  }
  return t;
}();

int _crc32(List<int> data, int crc) {
  var c = crc ^ 0xFFFFFFFF;
  for (var i = 0; i < data.length; i++) {
    c = _crcTable[(c ^ data[i]) & 0xFF] ^ (c >> 8);
  }
  return (c ^ 0xFFFFFFFF) & 0xFFFFFFFF;
}

int _dosTime(DateTime d) =>
    (d.hour << 11) | (d.minute << 5) | (d.second ~/ 2);
int _dosDate(DateTime d) {
  final y = d.year < 1980 ? 1980 : d.year;
  return ((y - 1980) << 9) | (d.month << 5) | d.day;
}

class _Done {
  _Done(this.name, this.crc, this.size, this.offset, this.time, this.date);
  final List<int> name;
  final int crc;
  final int size;
  final int offset;
  final int time;
  final int date;
}

/// Seedha stream hota zip64 (compression nahi = tez). Phone par koi temp file nahi banti,
/// RAM bhi bahut kam lagti hai; kitna bhi bada folder ho chalta hai.
Stream<List<int>> zipStream(List<ZipEntryInfo> entries) async* {
  var offset = 0;
  final done = <_Done>[];

  for (final e in entries) {
    FileStat st;
    try {
      st = await e.file.stat();
      if (st.type != FileSystemEntityType.file) continue;
    } catch (_) {
      continue;
    }
    final name = utf8.encode(e.rel);
    final time = _dosTime(st.modified);
    final date = _dosDate(st.modified);

    // Local header (sizes baad mein data descriptor mein)
    final h = ByteData(30 + name.length + 20);
    h.setUint32(0, 0x04034b50, Endian.little);
    h.setUint16(4, 45, Endian.little);
    h.setUint16(6, 0x0808, Endian.little);
    h.setUint16(8, 0, Endian.little);
    h.setUint16(10, time, Endian.little);
    h.setUint16(12, date, Endian.little);
    h.setUint32(14, 0, Endian.little);
    h.setUint32(18, 0xFFFFFFFF, Endian.little);
    h.setUint32(22, 0xFFFFFFFF, Endian.little);
    h.setUint16(26, name.length, Endian.little);
    h.setUint16(28, 20, Endian.little);
    final hb = h.buffer.asUint8List();
    hb.setRange(30, 30 + name.length, name);
    final x = 30 + name.length;
    h.setUint16(x, 1, Endian.little);
    h.setUint16(x + 2, 16, Endian.little);
    // baaki 16 bytes zero (usize, csize)
    yield hb;
    final start = offset;
    offset += hb.length;

    var crc = 0;
    var size = 0;
    await for (final chunk in e.file.openRead()) {
      crc = _crc32(chunk, crc);
      size += chunk.length;
      yield chunk;
    }
    offset += size;

    final d = ByteData(24);
    d.setUint32(0, 0x08074b50, Endian.little);
    d.setUint32(4, crc, Endian.little);
    d.setUint64(8, size, Endian.little);
    d.setUint64(16, size, Endian.little);
    yield d.buffer.asUint8List();
    offset += 24;

    done.add(_Done(name, crc, size, start, time, date));
  }

  // Central directory
  final cdStart = offset;
  for (final f in done) {
    final c = ByteData(46 + f.name.length + 28);
    c.setUint32(0, 0x02014b50, Endian.little);
    c.setUint16(4, 45, Endian.little);
    c.setUint16(6, 45, Endian.little);
    c.setUint16(8, 0x0808, Endian.little);
    c.setUint16(10, 0, Endian.little);
    c.setUint16(12, f.time, Endian.little);
    c.setUint16(14, f.date, Endian.little);
    c.setUint32(16, f.crc, Endian.little);
    c.setUint32(20, 0xFFFFFFFF, Endian.little);
    c.setUint32(24, 0xFFFFFFFF, Endian.little);
    c.setUint16(28, f.name.length, Endian.little);
    c.setUint16(30, 28, Endian.little);
    c.setUint16(32, 0, Endian.little);
    c.setUint16(34, 0, Endian.little);
    c.setUint16(36, 0, Endian.little);
    c.setUint32(38, 0, Endian.little);
    c.setUint32(42, 0xFFFFFFFF, Endian.little);
    final cb = c.buffer.asUint8List();
    cb.setRange(46, 46 + f.name.length, f.name);
    final x = 46 + f.name.length;
    c.setUint16(x, 1, Endian.little);
    c.setUint16(x + 2, 24, Endian.little);
    c.setUint64(x + 4, f.size, Endian.little);
    c.setUint64(x + 12, f.size, Endian.little);
    c.setUint64(x + 20, f.offset, Endian.little);
    yield cb;
    offset += cb.length;
  }
  final cdSize = offset - cdStart;

  final z = ByteData(56 + 20 + 22);
  z.setUint32(0, 0x06064b50, Endian.little);
  z.setUint64(4, 44, Endian.little);
  z.setUint16(12, 45, Endian.little);
  z.setUint16(14, 45, Endian.little);
  z.setUint32(16, 0, Endian.little);
  z.setUint32(20, 0, Endian.little);
  z.setUint64(24, done.length, Endian.little);
  z.setUint64(32, done.length, Endian.little);
  z.setUint64(40, cdSize, Endian.little);
  z.setUint64(48, cdStart, Endian.little);
  z.setUint32(56, 0x07064b50, Endian.little);
  z.setUint32(60, 0, Endian.little);
  z.setUint64(64, offset, Endian.little);
  z.setUint32(72, 1, Endian.little);
  z.setUint32(76, 0x06054b50, Endian.little);
  z.setUint16(80, 0, Endian.little);
  z.setUint16(82, 0, Endian.little);
  z.setUint16(84, 0xFFFF, Endian.little);
  z.setUint16(86, 0xFFFF, Endian.little);
  z.setUint32(88, 0xFFFFFFFF, Endian.little);
  z.setUint32(92, 0xFFFFFFFF, Endian.little);
  z.setUint16(96, 0, Endian.little);
  yield z.buffer.asUint8List();
}
