import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;

import '../core/format.dart';
import '../core/theme.dart';
import '../providers/browser_provider.dart';
import 'nearby_screen.dart';

class _Folder {
  _Folder(this.label, this.path);
  final String label;
  final String path;
  int? size; // null = abhi gin raha hai
  int files = 0;
  bool on = true;
}

/// "Phone khali karein": 3 aasan qadam. Folder chuno -> laptop chuno -> bhejo, check, hata do.
class CleanWizardScreen extends ConsumerStatefulWidget {
  const CleanWizardScreen({super.key});

  @override
  ConsumerState<CleanWizardScreen> createState() => _CleanWizardScreenState();
}

class _CleanWizardScreenState extends ConsumerState<CleanWizardScreen> {
  final List<_Folder> _folders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final root = ref.read(fileServiceProvider).root.path;
    final cands = <List<String>>[
      ['Camera / Photos / Videos (DCIM)', 'DCIM'],
      ['Pictures', 'Pictures'],
      ['Movies', 'Movies'],
      ['Music', 'Music'],
      ['Download', 'Download'],
      ['Documents', 'Documents'],
      ['WhatsApp (purana tarika)', 'WhatsApp'],
      ['WhatsApp (naya tarika)', p.join('Android', 'media', 'com.whatsapp', 'WhatsApp')],
      ['Recordings', 'Recordings'],
      ['Telegram', 'Telegram'],
    ];
    for (final c in cands) {
      final path = p.join(root, c[1]);
      try {
        if (await Directory(path).exists()) _folders.add(_Folder(c[0], path));
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() => _loading = false);
    for (final f in _folders) {
      var total = 0;
      var n = 0;
      try {
        await for (final e in Directory(f.path)
            .list(recursive: true, followLinks: false)
            .handleError((_) {})) {
          if (e is! File) continue;
          if (p.basename(e.path).startsWith('.')) continue;
          try {
            total += await e.length();
            n++;
          } catch (_) {}
        }
      } catch (_) {}
      f.size = total;
      f.files = n;
      if (!mounted) return;
      setState(() {});
    }
  }

  List<_Folder> get _picked => _folders.where((f) => f.on && (f.size ?? 1) > 0).toList();

  @override
  Widget build(BuildContext context) {
    final picked = _picked;
    final total = picked.fold<int>(0, (a, f) => a + (f.size ?? 0));
    final counting = _folders.any((f) => f.size == null);
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(
              8,
              MediaQuery.paddingOf(context).top + 8,
              16,
              22,
            ),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF6CC4F8), AppColors.skyDark],
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
            ),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                ),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Phone khali karein',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Laptop par copy → check → phone se hatao',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 640),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
                  children: [
                    _box(
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '3 aasan qadam',
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                          ),
                          SizedBox(height: 8),
                          Text(
                            '1. Laptop par SwiftFiles kholein → Transfer → "Aas paas ke devices". Dono ek hi Wi-Fi/hotspot par hon.\n'
                            '2. Neeche folder chunein aur "Aage: laptop chunein" dabayein. Laptop par tap karein, laptop par Accept karein.\n'
                            '3. Bhejna ho jaye to app khud check karti hai. Sab sahi ho to laal button se phone se hata dein.',
                            style: TextStyle(color: AppColors.muted, height: 1.45),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (_loading)
                      const Center(child: CircularProgressIndicator())
                    else if (_folders.isEmpty)
                      _box(const Text('Is device par koi aam folder nahi mila.'))
                    else
                      for (final f in _folders) ...[
                        _tile(f),
                        const SizedBox(height: 10),
                      ],
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    counting
                        ? 'Size gin raha hai…'
                        : '${picked.length} folder · ${formatSize(total)}',
                    style: const TextStyle(color: AppColors.muted),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: picked.isEmpty ? null : () => _next(picked),
                      icon: const Icon(Icons.arrow_forward_rounded),
                      label: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('Aage: laptop chunein'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _next(List<_Folder> picked) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(
        builder: (_) => NearbyScreen(paths: picked.map((f) => f.path).toList()),
      ),
    );
  }

  Widget _box(Widget child) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [
            BoxShadow(
              color: Color(0x141E88E5),
              blurRadius: 18,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: child,
      );

  Widget _tile(_Folder f) {
    final empty = f.size == 0;
    return _box(
      Row(
        children: [
          Checkbox(
            value: f.on && !empty,
            onChanged: empty ? null : (v) => setState(() => f.on = v ?? false),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  f.label,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                Text(
                  f.size == null
                      ? 'gin raha hai…'
                      : empty
                          ? 'khali'
                          : '${f.files} files · ${formatSize(f.size!)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
