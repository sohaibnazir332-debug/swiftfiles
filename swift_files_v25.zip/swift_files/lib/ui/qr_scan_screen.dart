import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';

/// Camera se QR padhta hai; pehla mila hua text wapas deta hai.
/// Pehle khud camera permission maangta hai; masla ho to asli wajah dikhata hai.
class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> with WidgetsBindingObserver {
  MobileScannerController? _c;
  bool _done = false;
  bool _checking = true;
  PermissionStatus? _perm;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ask();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _c?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Settings se wapas aane par dobara check
    if (state == AppLifecycleState.resumed && _c == null && !_checking) _ask();
  }

  Future<void> _ask() async {
    setState(() => _checking = true);
    PermissionStatus st;
    try {
      st = await Permission.camera.status;
      if (!st.isGranted) st = await Permission.camera.request();
    } catch (_) {
      // permission plugin na chale to scanner ko khud poochne dein
      st = PermissionStatus.granted;
    }
    if (!mounted) return;
    if (st.isGranted) {
      _c?.dispose();
      _c = MobileScannerController(
        formats: const [BarcodeFormat.qrCode],
        autoStart: true,
      );
    }
    setState(() {
      _perm = st;
      _checking = false;
    });
  }

  void _onDetect(BarcodeCapture cap) {
    if (_done) return;
    for (final b in cap.barcodes) {
      final v = b.rawValue;
      if (v != null && v.isNotEmpty) {
        _done = true;
        Navigator.pop(context, v);
        return;
      }
    }
  }

  Widget _msg(String text, {List<Widget> actions = const []}) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, height: 1.4),
              ),
              const SizedBox(height: 16),
              ...actions,
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_checking) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_perm == null || !_perm!.isGranted) {
      body = _msg(
        'Camera ki permission nahi mili.\nSettings kholein → Permissions → Camera → Allow, phir wapas aayein.',
        actions: [
          FilledButton(onPressed: openAppSettings, child: const Text('Settings kholein')),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: _ask,
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
            child: const Text('Dobara koshish'),
          ),
        ],
      );
    } else {
      body = Stack(
        children: [
          MobileScanner(
            controller: _c,
            onDetect: _onDetect,
            errorBuilder: (context, error, child) => _msg(
              'Camera shuru nahi hua.\nWajah: ${error.errorCode.name}'
              '${error.errorDetails?.message != null ? '\n${error.errorDetails!.message}' : ''}',
              actions: [
                FilledButton(onPressed: _ask, child: const Text('Dobara koshish')),
              ],
            ),
          ),
          const Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Dusre device ki screen par dikhne wala QR is box mein layein',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
            ),
          ),
        ],
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('QR scan karein'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: body,
    );
  }
}
