import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zxing2/qrcode.dart';

/// Camera se QR padhta hai (camera + pure-Dart zxing2: koi ML Kit / Google service nahi).
/// Mila hua text wapas deta hai. Masla ho to asli wajah screen par likhi aati hai.
class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> with WidgetsBindingObserver {
  CameraController? _c;
  bool _done = false;
  bool _busy = false;
  bool _checking = true;
  PermissionStatus? _perm;
  String? _err;
  int _lastMs = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _c?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _c == null && !_checking) _start();
  }

  Future<void> _start() async {
    setState(() {
      _checking = true;
      _err = null;
    });
    PermissionStatus st;
    try {
      st = await Permission.camera.status;
      if (!st.isGranted) st = await Permission.camera.request();
    } catch (_) {
      st = PermissionStatus.granted;
    }
    if (!mounted) return;
    if (!st.isGranted) {
      setState(() {
        _perm = st;
        _checking = false;
      });
      return;
    }
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) throw Exception('Is device mein camera nahi mila');
      final cam = cams.firstWhere(
        (x) => x.lensDirection == CameraLensDirection.back,
        orElse: () => cams.first,
      );
      await _c?.dispose();
      final c = CameraController(
        cam,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      await c.initialize();
      if (!mounted) {
        await c.dispose();
        return;
      }
      _c = c;
      await c.startImageStream(_onFrame);
      setState(() {
        _perm = st;
        _checking = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _perm = st;
        _err = e.toString();
        _checking = false;
      });
    }
  }

  void _onFrame(CameraImage img) {
    if (_done || _busy) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastMs < 350) return;
    _lastMs = now;
    _busy = true;
    try {
      final text = _decode(img);
      if (text != null && text.isNotEmpty) {
        _done = true;
        final c = _c;
        // stream rok kar result wapas dein
        (c?.stopImageStream() ?? Future<void>.value()).catchError((_) {}).whenComplete(() {
          if (mounted) Navigator.pop(context, text);
        });
      }
    } catch (_) {
      // frame mein QR nahi tha: agla frame
    } finally {
      _busy = false;
    }
  }

  String? _decode(CameraImage img) {
    final plane = img.planes[0];
    final w = img.width;
    final h = img.height;
    final stride = plane.bytesPerRow;
    final bytes = plane.bytes;
    final px = Int32List(w * h);
    for (var y = 0; y < h; y++) {
      final row = y * stride;
      for (var x = 0; x < w; x++) {
        final i = row + x;
        final v = i < bytes.length ? bytes[i] : 0;
        px[y * w + x] = 0xFF000000 | (v << 16) | (v << 8) | v;
      }
    }
    try {
      final bmp = BinaryBitmap(HybridBinarizer(RGBLuminanceSource(w, h, px)));
      return QRCodeReader().decode(bmp).text;
    } catch (_) {
      return null;
    }
  }

  Widget _msg(String text, {List<Widget> actions = const []}) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, height: 1.4),
              ),
              const SizedBox(height: 16),
              ...actions,
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_checking) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_perm == null || !_perm!.isGranted) {
      body = _msg(
        'Camera ki permission nahi mili.\nSettings kholein → Permissions → Camera → Allow, phir wapas aayein.',
        actions: [
          FilledButton(onPressed: openAppSettings, child: const Text('Settings kholein')),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: _start,
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
            child: const Text('Dobara koshish'),
          ),
        ],
      );
    } else if (_err != null || _c == null || !_c!.value.isInitialized) {
      body = _msg(
        'Camera shuru nahi hua.\n${_err ?? ''}',
        actions: [FilledButton(onPressed: _start, child: const Text('Dobara koshish'))],
      );
    } else {
      body = Stack(
        fit: StackFit.expand,
        children: [
          Center(child: CameraPreview(_c!)),
          Center(
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 3),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          const Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Dusre device ki screen par dikhne wala QR is box mein layein. Screen ki roshni badha dein.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
            ),
          ),
        ],
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('QR scan karein'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: body,
    );
  }
}
